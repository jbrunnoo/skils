# Skills PrimeVue - Estrutura Modular

Coleção de skills enxutas e focadas para cada componente do PrimeVue.

## 📁 Estrutura

```
primevue/
├── general/
│   └── SKILL.md          # Setup, configuração, breaking changes
└── components/
    ├── button/
    │   └── SKILL.md
    ├── inputtext/
    │   └── SKILL.md
    ├── select/
    │   └── SKILL.md
    ├── datatable/
    │   └── SKILL.md
    ├── dialog/
    │   └── SKILL.md
    ├── card/
    │   └── SKILL.md
    ├── datepicker/
    │   └── SKILL.md
    ├── checkbox/
    │   └── SKILL.md
    ├── radiobutton/
    │   └── SKILL.md
    ├── tabs/
    │   └── SKILL.md
    ├── menu/
    │   └── SKILL.md
    ├── stepper/
    │   └── SKILL.md
    ├── accordion/
    │   └── SKILL.md
    ├── drawer/
    │   └── SKILL.md
    └── popover/
        └── SKILL.md
```

## 🎯 Como Usar

### No Cursor

O Cursor automaticamente detecta e usa as skills relevantes quando você menciona componentes específicos.

**Exemplo:**
- "Crie um botão usando PrimeVue" → usa `button/SKILL.md`
- "Crie uma tabela de dados" → usa `datatable/SKILL.md`
- "Configure o PrimeVue" → usa `general/SKILL.md`

### Uso Manual

Você também pode pedir explicitamente:
- "Use a skill de DataTable para criar uma tabela"
- "Consulte a skill de Dialog para criar um modal"

## 📦 Skills Disponíveis

### Geral
- **general/SKILL.md** - Setup, instalação, configuração, breaking changes v3→v4

### Componentes (92 skills)

**Formulários e Inputs:**
1. AutoComplete, InputText, InputNumber, Input, InputGroup
2. Select, MultiSelect, Listbox, CascadeSelect, TreeSelect
3. Password, Textarea, OtpInput
4. Checkbox, RadioButton, ToggleSwitch, ToggleButton, SelectButton
5. DatePicker, ColorPicker, Slider, Knob, Rating
6. FileUpload, KeyFilter, Mask

**Layout e Estrutura:**
7. Card, Panel, Fieldset, Divider
8. Splitter, ScrollPanel, ScrollTop
9. Fluid, IconField, IftaLabel, FloatLabel
10. InputGroup, Dock

**Navegação:**
11. Menu, ContextMenu, TieredMenu, MegaMenu, PanelMenu
12. Breadcrumb, Tabs, Stepper, Accordion
13. Navbar, Toolbar, Dock

**Dados:**
14. DataTable, Table, TreeTable, DataView
15. Tree, Paginator, VirtualScroller
16. OrderList, PickList

**Overlay:**
17. Dialog, DynamicDialog, ConfirmationDialog
18. Drawer, Popover, BlockUI
19. Toast, Message

**Feedback:**
20. ProgressBar, ProgressSpinner, Skeleton
21. Badge, Chip, Tag, Avatar
22. MeterGroup

**Mídia:**
23. Image, ImageCompare, Gallery, Carousel

**Outros:**
24. Button, SplitButton, SpeedDial
25. Chart, Editor, Terminal
26. Timeline, OrganizationChart
27. Inplace, DeferredContent
28. Ripple, FocusTrap, StyleClass, Tooltip, AnimateOnScroll

## ✨ Vantagens

✅ **Skills Enxutas** - Cada skill foca apenas no essencial do componente  
✅ **Contexto Otimizado** - Não sobrecarrega o contexto do modelo  
✅ **Fácil Manutenção** - Atualize um componente sem afetar outros  
✅ **Uso Seletivo** - O Cursor usa apenas as skills relevantes  
✅ **Breaking Changes** - Todas as skills documentam mudanças v3→v4

## 🔄 Breaking Changes Documentados

Todas as skills que sofreram mudanças na v4 incluem seção de migração:
- `Dropdown` → `Select`
- `Calendar` → `DatePicker`
- `Sidebar` → `Drawer`
- `OverlayPanel` → `Popover`
- `TabView` → `Tabs`
- `Steps` → `Stepper`
- `InputSwitch` → `ToggleSwitch`

## 📚 Referências

Cada skill inclui links para:
- Documentação oficial do componente
- API Reference completa

## 🚀 Próximos Passos

Para adicionar mais componentes, crie uma nova pasta em `components/` com um `SKILL.md` seguindo o mesmo padrão das skills existentes.
