# 📊 Exemplos de Prompts para Dashboard com PrimeVue

Este arquivo contém exemplos práticos de prompts para criar dashboards usando o ecossistema de skills do PrimeVue.

---

## 🎯 Exemplo 1: Dashboard Genérico Completo

### Prompt:

```
Crie um dashboard administrativo completo usando PrimeVue com os seguintes componentes:

1. **Header/Navbar:**
   - Logo e título do sistema
   - Menu de navegação horizontal
   - Avatar do usuário com menu dropdown
   - Badge de notificações

2. **Sidebar/Menu Lateral:**
   - Menu vertical com ícones
   - Itens: Dashboard, Usuários, Relatórios, Configurações
   - Indicador de item ativo

3. **Área Principal:**
   - **Cards de Métricas** (4 cards lado a lado):
     * Total de Vendas (com ícone e tendência)
     * Novos Usuários (com badge)
     * Receita Mensal (com gráfico pequeno)
     * Pedidos Pendentes (com status)
   
   - **Gráfico Principal:**
     * Chart de linha mostrando vendas dos últimos 6 meses
   
   - **Tabela de Dados:**
     * DataTable com últimas transações
     * Colunas: Data, Cliente, Valor, Status
     * Paginação e ordenação
     * Filtros por status
   
   - **Lista de Atividades Recentes:**
     * Timeline ou lista com últimas ações
     * Avatar, descrição e timestamp

4. **Footer:**
   - Informações de copyright
   - Links úteis

**Requisitos:**
- Use tema Aura do PrimeVue
- Layout responsivo (Splitter para sidebar)
- Componentes nativos sem customizações pesadas
- Acessibilidade WCAG 2.1 AA
- Dados mockados para demonstração

**Use as skills do PrimeVue para cada componente mencionado.**
```

### Componentes que serão usados:
- `navbar` - Header
- `menu` / `panelmenu` - Sidebar
- `card` - Cards de métricas
- `chart` - Gráficos
- `datatable` - Tabela de dados
- `timeline` - Atividades recentes
- `badge` - Badges e notificações
- `avatar` - Avatar do usuário
- `splitter` - Layout responsivo
- `divider` - Separadores

---

## 🎯 Exemplo 2: Dashboard a partir de Screenshot/Print

### Prompt:

```
Analise este screenshot/print de dashboard e recrie usando componentes nativos do PrimeVue.

**Descrição do que vejo no print:**
- Layout em grid com 3 colunas
- Cards coloridos no topo com métricas (verde, azul, laranja, vermelho)
- Gráfico de barras centralizado
- Tabela de dados abaixo com paginação
- Menu lateral esquerdo colapsável
- Header fixo no topo

**Requisitos:**
1. Use componentes PrimeVue nativos:
   - Card para os boxes de métricas
   - Chart para o gráfico de barras
   - DataTable para a tabela
   - Drawer ou Panel para o menu lateral
   - Toolbar para o header

2. Mantenha o layout similar ao print:
   - Use Grid/Flexbox do PrimeVue
   - Cores dos cards conforme o print
   - Espaçamento e padding similar

3. Dados mockados:
   - Crie dados de exemplo que façam sentido
   - Use formatação adequada (moeda, datas, etc)

4. Responsividade:
   - Em mobile, sidebar vira drawer
   - Cards empilham verticalmente
   - Tabela fica scrollável horizontalmente

**Use as skills específicas de cada componente do PrimeVue.**
```

### Componentes que serão usados:
- `drawer` - Menu lateral colapsável
- `toolbar` - Header fixo
- `card` - Cards de métricas coloridos
- `chart` - Gráfico de barras
- `datatable` - Tabela com paginação
- `fluid` - Sistema de grid responsivo
- `badge` - Indicadores nos cards
- `progressbar` - Se houver indicadores de progresso

---

## 🎯 Exemplo 3: Dashboard de Analytics com Filtros Avançados

### Prompt:

```
Crie um dashboard de analytics avançado usando PrimeVue com:

**1. Barra de Filtros Superior:**
   - DatePicker para selecionar período (range)
   - Select para escolher categoria
   - MultiSelect para selecionar múltiplas regiões
   - Button para aplicar filtros
   - Button para exportar dados

**2. Cards de KPIs (Key Performance Indicators):**
   - 6 cards em grid responsivo:
     * Visitantes (com ícone de usuários)
     * Taxa de Conversão (com percentual e tendência)
     * Receita Total (com formatação de moeda)
     * Tempo Médio de Sessão (com formato de tempo)
     * Taxa de Rejeição (com indicador de cor)
     * Páginas por Sessão (com número formatado)

**3. Seção de Gráficos:**
   - **Gráfico 1:** Chart de linha - Tráfego ao longo do tempo
   - **Gráfico 2:** Chart de pizza - Distribuição por fonte
   - **Gráfico 3:** Chart de barras - Top 10 páginas mais visitadas

**4. Tabela Detalhada:**
   - DataTable com dados de sessões
   - Colunas: Data/Hora, IP, Página, Duração, Status
   - Filtros por coluna
   - Ordenação
   - Paginação (10 itens por página)
   - Exportação para CSV

**5. Painel de Ações Rápidas:**
   - SpeedDial com ações: Exportar, Compartilhar, Configurar
   - Toast para feedback de ações

**Requisitos Técnicos:**
- Use tema Aura do PrimeVue
- Todos os componentes devem ser nativos
- Dados mockados realistas
- Loading states (Skeleton ou ProgressSpinner)
- Mensagens de erro amigáveis (Message component)
- Acessibilidade completa
- Performance otimizada (DeferredContent para gráficos pesados)

**Consulte as skills de cada componente antes de implementar.**
```

### Componentes que serão usados:
- `datepicker` - Seleção de período
- `select` - Seleção de categoria
- `multiselect` - Seleção múltipla de regiões
- `button` - Botões de ação
- `card` - Cards de KPIs
- `chart` - Todos os gráficos
- `datatable` - Tabela detalhada
- `speeddial` - Ações rápidas
- `toast` - Notificações
- `message` - Mensagens de erro
- `skeleton` - Loading states
- `deferredcontent` - Carregamento otimizado
- `badge` - Indicadores
- `tooltip` - Dicas nos gráficos

---

## 📝 Dicas para Usar os Prompts

### ✅ Boas Práticas:

1. **Seja Específico:**
   - Mencione componentes específicos do PrimeVue
   - Descreva o layout desejado
   - Indique funcionalidades necessárias

2. **Mencione as Skills:**
   - Sempre peça para usar as skills do PrimeVue
   - Isso garante código atualizado e correto

3. **Detalhe os Requisitos:**
   - Responsividade
   - Acessibilidade
   - Temas
   - Dados mockados

4. **Para Screenshots:**
   - Descreva o que você vê
   - Mencione cores, layout, componentes visíveis
   - Peça para usar componentes nativos equivalentes

### 🎨 Exemplo de Prompt para Screenshot (mais detalhado):

```
Tenho um screenshot de um dashboard. Analise e recrie usando PrimeVue.

**Análise do Screenshot:**

**Layout:**
- Menu lateral esquerdo fixo (200px de largura)
- Header fixo no topo (60px de altura)
- Conteúdo principal com scroll
- Footer fixo na parte inferior

**Componentes Visíveis:**
1. **Menu Lateral:**
   - Logo no topo
   - Lista de itens com ícones à esquerda
   - Item ativo destacado em azul
   - Separador antes de "Configurações"

2. **Header:**
   - Título "Dashboard" à esquerda
   - Campo de busca centralizado
   - Avatar + nome do usuário à direita
   - Badge de notificações (número 5)

3. **Conteúdo:**
   - 4 cards em linha (quebram em 2x2 no mobile)
   - Cada card tem: ícone colorido, título, número grande, subtítulo
   - Gráfico de linha abaixo dos cards
   - Tabela com 5 colunas e 10 linhas
   - Paginação na parte inferior da tabela

**Cores Observadas:**
- Azul primário: #3B82F6
- Verde: #10B981
- Laranja: #F59E0B
- Vermelho: #EF4444
- Fundo: #F9FAFB

**Requisitos:**
- Use Drawer para menu lateral (colapsável em mobile)
- Use Toolbar para header
- Use Card para os boxes de métricas
- Use Chart para o gráfico
- Use DataTable para a tabela
- Use tema Aura com cores customizadas se necessário
- Mantenha o layout o mais próximo possível do screenshot

**Use as skills do PrimeVue para garantir código correto.**
```

---

## 🚀 Como Usar

1. **Copie um dos prompts acima** e adapte para suas necessidades
2. **Cole no Cursor** e deixe o system prompt trabalhar
3. **O Cursor consultará automaticamente** as skills necessárias
4. **Revise o código gerado** e ajuste se necessário

---

## 📚 Referências

- Skills disponíveis: `/Users/jeffersonbruno/skills/primevue/components/`
- System Prompt: `.cursorrules`
- Documentação: `README.md`

---

**💡 Dica:** Quanto mais detalhado for seu prompt, melhor será o resultado gerado pelo Cursor usando as skills do PrimeVue!
