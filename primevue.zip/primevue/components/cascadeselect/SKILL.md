# PrimeVue CascadeSelect Component

Componente de seleção em cascata hierárquica (ex: País > Estado > Cidade).

## Import

```javascript
import CascadeSelect from 'primevue/cascadeselect';
```

## Uso Básico

```vue
<CascadeSelect 
  v-model="selected" 
  :options="options" 
  optionLabel="name"
  optionGroupLabel="label"
  optionGroupChildren="items"
  placeholder="Selecione"
/>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `options` | array | Opções hierárquicas |
| `optionLabel` | string | Propriedade para label |
| `optionValue` | string | Propriedade para value |
| `optionGroupLabel` | string | Label do grupo |
| `optionGroupChildren` | string | Propriedade com filhos |
| `placeholder` | string | Placeholder |
| `disabled` | boolean | Desabilita |
| `showClear` | boolean | Mostra botão limpar |

## Exemplos

### Seleção de Localização

```vue
<template>
  <CascadeSelect 
    v-model="localizacao" 
    :options="localizacoes" 
    optionLabel="name"
    optionValue="code"
    optionGroupLabel="label"
    optionGroupChildren="items"
    placeholder="Selecione País > Estado > Cidade"
  />
</template>

<script setup>
import { ref } from 'vue'
const localizacao = ref(null)
const localizacoes = ref([
  {
    label: 'Brasil',
    items: [
      {
        label: 'São Paulo',
        items: [
          { name: 'São Paulo', code: 'SP-CAP' },
          { name: 'Campinas', code: 'SP-CAM' }
        ]
      },
      {
        label: 'Rio de Janeiro',
        items: [
          { name: 'Rio de Janeiro', code: 'RJ-CAP' },
          { name: 'Niterói', code: 'RJ-NIT' }
        ]
      }
    ]
  }
])
</script>
```

### Com Botão Limpar

```vue
<CascadeSelect 
  v-model="selected" 
  :options="options" 
  optionLabel="name"
  optionGroupLabel="label"
  optionGroupChildren="items"
  showClear
/>
```

### Com Ícone

```vue
<IconField>
  <InputIcon class="pi pi-map-marker" />
  <CascadeSelect 
    v-model="selected" 
    :options="options" 
    optionLabel="name"
    optionGroupLabel="label"
    optionGroupChildren="items"
  />
</IconField>
```

## Estrutura de Dados

```typescript
interface CascadeOption {
  label: string
  items: Array<{
    label?: string
    items?: Array<{ name: string, code: string }>
    name?: string
    code?: string
  }>
}
```

## Casos de Uso

- Seleção de localização (País > Estado > Cidade)
- Seleção de categoria (Categoria > Subcategoria > Produto)
- Navegação hierárquica em formulários
- Filtros em cascata

## Referências

- [Documentação Oficial](https://primevue.org/cascadeselect)
- [API Reference](https://primevue.org/api/cascadeselect)
