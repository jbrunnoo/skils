# PrimeVue Dialog Component

Componente de diálogo/modal do PrimeVue.

## Import

```javascript
import Dialog from 'primevue/dialog';
```

## Uso Básico

```vue
<Dialog v-model:visible="show" header="Título" :modal="true">
  <p>Conteúdo do diálogo</p>
</Dialog>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `visible` | boolean | Visibilidade (v-model:visible) |
| `header` | string | Título do diálogo |
| `modal` | boolean | Modal (bloqueia interação fora) |
| `draggable` | boolean | Permite arrastar |
| `resizable` | boolean | Permite redimensionar |
| `position` | string | Posição: "center", "top", "bottom", etc. |
| `closable` | boolean | Mostra botão fechar |
| `dismissableMask` | boolean | Fecha ao clicar fora |
| `maximizable` | boolean | Permite maximizar |

## Exemplos

### Básico

```vue
<template>
  <Button label="Abrir" @click="show = true" />
  <Dialog v-model:visible="show" header="Meu Diálogo">
    <p>Conteúdo aqui</p>
  </Dialog>
</template>

<script setup>
import { ref } from 'vue'
const show = ref(false)
</script>
```

### Modal

```vue
<Dialog 
  v-model:visible="show" 
  header="Confirmação"
  :modal="true"
  :closable="true"
>
  <p>Tem certeza que deseja continuar?</p>
  <template #footer>
    <Button label="Cancelar" @click="show = false" />
    <Button label="Confirmar" @click="confirm()" />
  </template>
</Dialog>
```

### Com Template Customizado

```vue
<Dialog v-model:visible="show">
  <template #header>
    <div class="flex items-center gap-2">
      <i class="pi pi-info-circle"></i>
      <span>Título Customizado</span>
    </div>
  </template>
  
  <p>Conteúdo</p>
  
  <template #footer>
    <Button label="Fechar" @click="show = false" />
  </template>
</Dialog>
```

### Arrastável e Redimensionável

```vue
<Dialog 
  v-model:visible="show"
  header="Diálogo Customizável"
  :draggable="true"
  :resizable="true"
>
  <p>Arraste e redimensione este diálogo</p>
</Dialog>
```

### Posicionamento

```vue
<Dialog 
  v-model:visible="show"
  header="Topo"
  position="top"
>
  <p>Diálogo no topo</p>
</Dialog>
```

### Maximizável

```vue
<Dialog 
  v-model:visible="show"
  header="Maximizável"
  :maximizable="true"
>
  <p>Clique no ícone para maximizar</p>
</Dialog>
```

## Acessibilidade

- Foco automático no diálogo ao abrir
- Fecha com ESC
- Compatível com leitores de tela
- Gerencia foco corretamente

## Referências

- [Documentação Oficial](https://primevue.org/dialog)
- [API Reference](https://primevue.org/api/dialog)
