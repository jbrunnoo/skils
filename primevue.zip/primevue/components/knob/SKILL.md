# PrimeVue Knob Component

Componente knob (controle circular) para valores numéricos.

## Import

```javascript
import Knob from 'primevue/knob';
```

## Uso Básico

```vue
<Knob v-model="value" :min="0" :max="100" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | number | Valor (v-model) |
| `min` | number | Valor mínimo |
| `max` | number | Valor máximo |
| `step` | number | Incremento |
| `size` | number | Tamanho em pixels |
| `strokeWidth` | number | Largura do traço |
| `disabled` | boolean | Desabilita |
| `readonly` | boolean | Somente leitura |
| `showValue` | boolean | Mostra valor |

## Exemplos

### Básico

```vue
<template>
  <Knob v-model="volume" :min="0" :max="100" />
  <p>Volume: {{ volume }}%</p>
</template>

<script setup>
const volume = ref(50)
</script>
```

### Com Tamanho Customizado

```vue
<Knob v-model="valor" :min="0" :max="100" :size="150" />
```

### Com Step

```vue
<Knob v-model="valor" :min="0" :max="100" :step="5" />
```

### Sem Valor Visível

```vue
<Knob v-model="valor" :min="0" :max="100" :showValue="false" />
```

### Com Cores Customizadas

```vue
<Knob 
  v-model="valor" 
  :min="0" 
  :max="100"
  valueColor="#42A5F5"
  rangeColor="#66BB6A"
/>
```

### Múltiplos Knobs

```vue
<div class="flex gap-4">
  <div class="flex flex-column align-items-center">
    <label>Volume</label>
    <Knob v-model="volume" :min="0" :max="100" />
  </div>
  <div class="flex flex-column align-items-center">
    <label>Brilho</label>
    <Knob v-model="brilho" :min="0" :max="100" />
  </div>
</div>
```

## Casos de Uso

- Controles de áudio/vídeo
- Configurações de ajustes
- Controles de dashboard
- Sliders circulares

## Referências

- [Documentação Oficial](https://primevue.org/knob)
- [API Reference](https://primevue.org/api/knob)
