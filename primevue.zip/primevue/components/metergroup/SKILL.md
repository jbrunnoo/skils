# PrimeVue MeterGroup Component

Grupo de medidores/gauges para exibir múltiplos valores.

## Import

```javascript
import MeterGroup from 'primevue/metergroup';
```

## Uso Básico

```vue
<MeterGroup :value="values" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Valores dos medidores |
| `min` | number | Valor mínimo |
| `max` | number | Valor máximo |
| `orientation` | string | "horizontal" ou "vertical" |

## Exemplos

### Básico

```vue
<template>
  <MeterGroup :value="valores" />
</template>

<script setup>
const valores = ref([
  { label: 'CPU', value: 75 },
  { label: 'RAM', value: 60 },
  { label: 'Disco', value: 90 }
])
</script>
```

### Com Labels

```vue
<MeterGroup 
  :value="valores" 
  :min="0" 
  :max="100"
  labelPosition="start"
/>
```

### Horizontal

```vue
<MeterGroup 
  :value="valores" 
  orientation="horizontal"
/>
```

### Com Cores

```vue
const valores = ref([
  { label: 'CPU', value: 75, color: '#42A5F5' },
  { label: 'RAM', value: 60, color: '#66BB6A' },
  { label: 'Disco', value: 90, color: '#FFA726' }
])
```

## Estrutura de Valor

```typescript
interface MeterValue {
  label: string
  value: number
  color?: string
}
```

## Casos de Uso

- Dashboards de sistema
- Monitoramento de recursos
- Indicadores de performance
- Métricas visuais

## Referências

- [Documentação Oficial](https://primevue.org/metergroup)
- [API Reference](https://primevue.org/api/metergroup)
