# PrimeVue InputText Component

Componente de input de texto do PrimeVue.

## Import

```javascript
import InputText from 'primevue/inputtext';
```

## Uso Básico

```vue
<InputText v-model="value" placeholder="Digite algo" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | string | Valor (v-model) |
| `placeholder` | string | Placeholder |
| `disabled` | boolean | Desabilita o input |
| `readonly` | boolean | Apenas leitura |
| `size` | string | Tamanho: "small", "large" |
| `invalid` | boolean | Estado inválido |
| `variant` | string | Variante: "filled", "outlined" |

## Exemplos

### Básico

```vue
<template>
  <InputText v-model="texto" placeholder="Digite seu nome" />
</template>

<script setup>
import { ref } from 'vue'
const texto = ref('')
</script>
```

### Com Ícone

```vue
<IconField>
  <InputIcon class="pi pi-search" />
  <InputText v-model="search" placeholder="Buscar" />
</IconField>
```

### Tamanhos

```vue
<InputText v-model="value" size="small" placeholder="Pequeno" />
<InputText v-model="value" placeholder="Normal" />
<InputText v-model="value" size="large" placeholder="Grande" />
```

### Estados

```vue
<InputText v-model="value" disabled placeholder="Desabilitado" />
<InputText v-model="value" readonly placeholder="Somente leitura" />
<InputText v-model="value" invalid placeholder="Inválido" />
```

### Variantes

```vue
<!-- Outlined (padrão) -->
<InputText v-model="value" placeholder="Outlined" />

<!-- Filled -->
<div class="p-variant-filled">
  <InputText v-model="value" placeholder="Filled" />
</div>
```

### Com Label

```vue
<IftaLabel for="username">Usuário</IftaLabel>
<InputText id="username" v-model="username" />
```

## Acessibilidade

- Use `IftaLabel` para labels acessíveis
- Suporte a `aria-invalid` quando `invalid={true}`
- Compatível com leitores de tela

## Referências

- [Documentação Oficial](https://primevue.org/inputtext)
- [API Reference](https://primevue.org/api/inputtext)
