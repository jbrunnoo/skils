# PrimeVue Tooltip Directive

Diretiva de tooltip para mostrar dicas ao passar o mouse.

## Import

```javascript
import Tooltip from 'primevue/tooltip';
```

## Configuração Global

```javascript
app.directive('tooltip', Tooltip);
```

## Uso Básico

```vue
<Button v-tooltip="'Dica de ajuda'" label="Hover aqui" />
```

## Exemplos

### Básico

```vue
<Button v-tooltip="'Clique para salvar'" label="Salvar" />
```

### Com Posição

```vue
<Button 
  v-tooltip.left="'Dica à esquerda'" 
  label="Esquerda" 
/>
<Button 
  v-tooltip.right="'Dica à direita'" 
  label="Direita" 
/>
<Button 
  v-tooltip.top="'Dica acima'" 
  label="Topo" 
/>
<Button 
  v-tooltip.bottom="'Dica abaixo'" 
  label="Baixo" 
/>
```

### Com Opções

```vue
<Button 
  v-tooltip="{ value: 'Dica', position: 'top', showDelay: 500 }" 
  label="Com Delay" 
/>
```

### Com Template

```vue
<Button 
  v-tooltip="'Dica customizada'"
  label="Botão"
/>
```

### Em Inputs

```vue
<InputText 
  v-model="value" 
  v-tooltip="'Digite seu nome completo'"
  placeholder="Nome"
/>
```

## Opções

```typescript
interface TooltipOptions {
  value: string
  position?: 'top' | 'bottom' | 'left' | 'right'
  showDelay?: number
  hideDelay?: number
  autoHide?: boolean
  mouseTrack?: boolean
}
```

## Casos de Uso

- Dicas de ajuda
- Explicações de campos
- Informações adicionais
- Guias de uso

## Referências

- [Documentação Oficial](https://primevue.org/tooltip)
- [API Reference](https://primevue.org/api/tooltip)
