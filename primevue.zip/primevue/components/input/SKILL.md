# PrimeVue Input Component

Componente input genérico (use InputText para texto específico).

## Import

```javascript
import Input from 'primevue/input';
```

## Uso Básico

```vue
<Input v-model="value" type="text" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor (v-model) |
| `type` | string | Tipo: "text", "email", "password", etc. |
| `disabled` | boolean | Desabilita |
| `readonly` | boolean | Somente leitura |

## Exemplos

### Básico

```vue
<Input v-model="valor" type="text" />
```

### Diferentes Tipos

```vue
<Input v-model="email" type="email" />
<Input v-model="senha" type="password" />
<Input v-model="numero" type="number" />
<Input v-model="url" type="url" />
```

## Nota

Para inputs de texto, prefira usar `InputText` que tem mais recursos e melhor integração com PrimeVue.

## Referências

- [Documentação Oficial](https://primevue.org/input)
- [API Reference](https://primevue.org/api/input)
