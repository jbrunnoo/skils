# PrimeVue PickList Component

Lista de seleção com transferência entre duas listas (source e target).

## Import

```javascript
import PickList from 'primevue/picklist';
```

## Uso Básico

```vue
<PickList 
  v-model="lists" 
  :source="source" 
  :target="target"
  dataKey="id"
/>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | object | {source: [], target: []} |
| `source` | array | Lista origem |
| `target` | array | Lista destino |
| `dataKey` | string | Chave única |
| `sourceHeader` | string | Título da lista origem |
| `targetHeader` | string | Título da lista destino |

## Exemplos

### Básico

```vue
<template>
  <PickList 
    v-model="lists" 
    :source="source" 
    :target="target"
    dataKey="id"
    sourceHeader="Disponíveis"
    targetHeader="Selecionados"
  >
    <template #item="slotProps">
      <div>{{ slotProps.item.nome }}</div>
    </template>
  </PickList>
</template>

<script setup>
const source = ref([
  { id: 1, nome: 'Item 1' },
  { id: 2, nome: 'Item 2' },
  { id: 3, nome: 'Item 3' }
])
const target = ref([])
const lists = ref({ source: source.value, target: target.value })
</script>
```

### Com Template Customizado

```vue
<PickList v-model="lists" :source="source" :target="target" dataKey="id">
  <template #item="slotProps">
    <div class="flex justify-between p-2">
      <span>{{ slotProps.item.nome }}</span>
      <Badge :value="slotProps.item.categoria" />
    </div>
  </template>
</PickList>
```

### Com Filtro

```vue
<PickList 
  v-model="lists" 
  :source="source" 
  :target="target"
  dataKey="id"
  :sourceFilter="true"
  :targetFilter="true"
/>
```

## Casos de Uso

- Seleção de permissões
- Atribuição de usuários
- Transferência de itens
- Gerenciamento de listas

## Referências

- [Documentação Oficial](https://primevue.org/picklist)
- [API Reference](https://primevue.org/api/picklist)
