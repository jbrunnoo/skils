# PrimeVue Carousel Component

Componente carrossel para exibir imagens ou conteúdo em slides.

## Import

```javascript
import Carousel from 'primevue/carousel';
```

## Uso Básico

```vue
<Carousel :value="items" :numVisible="3" :numScroll="1">
  <template #item="slotProps">
    <div>{{ slotProps.data }}</div>
  </template>
</Carousel>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Itens do carrossel |
| `numVisible` | number | Número de itens visíveis |
| `numScroll` | number | Itens a scrollar por vez |
| `circular` | boolean | Loop infinito |
| `autoplayInterval` | number | Intervalo de autoplay (ms) |
| `responsiveOptions` | array | Opções responsivas |
| `orientation` | string | "horizontal" ou "vertical" |
| `verticalViewPortHeight` | string | Altura no modo vertical |

## Exemplos

### Básico

```vue
<template>
  <Carousel :value="produtos" :numVisible="3" :numScroll="1">
    <template #item="slotProps">
      <div class="p-3 border">
        <img :src="slotProps.data.imagem" :alt="slotProps.data.nome" />
        <h3>{{ slotProps.data.nome }}</h3>
        <p>{{ slotProps.data.preco }}</p>
      </div>
    </template>
  </Carousel>
</template>

<script setup>
const produtos = ref([
  { nome: 'Produto 1', preco: 'R$ 100', imagem: '/img1.jpg' },
  { nome: 'Produto 2', preco: 'R$ 200', imagem: '/img2.jpg' },
  { nome: 'Produto 3', preco: 'R$ 300', imagem: '/img3.jpg' }
])
</script>
```

### Com Autoplay

```vue
<Carousel 
  :value="items" 
  :numVisible="1" 
  :circular="true"
  :autoplayInterval="3000"
/>
```

### Responsivo

```vue
<Carousel 
  :value="items" 
  :numVisible="3"
  :responsiveOptions="responsiveOptions"
/>

<script setup>
const responsiveOptions = ref([
  {
    breakpoint: '1024px',
    numVisible: 3,
    numScroll: 3
  },
  {
    breakpoint: '768px',
    numVisible: 2,
    numScroll: 2
  },
  {
    breakpoint: '560px',
    numVisible: 1,
    numScroll: 1
  }
])
</script>
```

### Vertical

```vue
<Carousel 
  :value="items" 
  :numVisible="1"
  orientation="vertical"
  verticalViewPortHeight="400px"
/>
```

## Referências

- [Documentação Oficial](https://primevue.org/carousel)
- [API Reference](https://primevue.org/api/carousel)
