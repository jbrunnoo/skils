# PrimeVue TreeSelect Component

Componente de seleção em estrutura de árvore.

## Import

```javascript
import TreeSelect from 'primevue/treeselect';
```

## Uso Básico

```vue
<TreeSelect v-model="selected" :options="nodes" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `options` | array | Nós da árvore |
| `selectionMode` | string | "single" ou "checkbox" |
| `placeholder` | string | Placeholder |
| `filter` | boolean | Habilita filtro |

## Exemplos

### Básico

```vue
<template>
  <TreeSelect 
    v-model="selecionado" 
    :options="nodes" 
    placeholder="Selecione"
  />
</template>

<script setup>
const selecionado = ref(null)
const nodes = ref([
  {
    key: '0',
    label: 'Documentos',
    children: [
      {
        key: '0-0',
        label: 'Trabalho',
        children: [
          { key: '0-0-0', label: 'Relatório.pdf' },
          { key: '0-0-1', label: 'Apresentação.pptx' }
        ]
      }
    ]
  }
])
</script>
```

### Com Checkbox

```vue
<TreeSelect 
  v-model="selecionados" 
  :options="nodes" 
  selectionMode="checkbox"
/>
```

### Com Filtro

```vue
<TreeSelect 
  v-model="selecionado" 
  :options="nodes" 
  filter
  filterPlaceholder="Buscar..."
/>
```

## Estrutura de Nó

```typescript
interface TreeNode {
  key: string
  label: string
  data?: any
  children?: TreeNode[]
}
```

## Casos de Uso

- Seleção de categorias
- Navegação de arquivos
- Estruturas hierárquicas
- Seleção em árvore

## Referências

- [Documentação Oficial](https://primevue.org/treeselect)
- [API Reference](https://primevue.org/api/treeselect)
