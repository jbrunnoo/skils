# PrimeVue DynamicDialog Component

Criação dinâmica de diálogos programaticamente.

## Import

```javascript
import DynamicDialog from 'primevue/dynamicdialog';
import { useDialog } from 'primevue/usedialog';
```

## Uso Básico

```vue
<template>
  <DynamicDialog />
  <Button @click="abrirDialog" label="Abrir" />
</template>

<script setup>
import { useDialog } from 'primevue/usedialog'
const dialog = useDialog()

const abrirDialog = () => {
  dialog.open(MeuComponente, {
    props: {
      titulo: 'Título do Dialog',
      dados: { /* dados */ }
    },
    onClose: (options) => {
      // Callback ao fechar
    }
  })
}
</script>
```

## Exemplos

### Básico

```vue
<template>
  <DynamicDialog />
  <Button @click="mostrar" label="Mostrar Dialog" />
</template>

<script setup>
import MeuComponente from './MeuComponente.vue'
const dialog = useDialog()

const mostrar = () => {
  dialog.open(MeuComponente, {
    props: {
      titulo: 'Meu Dialog'
    }
  })
}
</script>
```

### Com Opções

```vue
dialog.open(Componente, {
  props: {
    titulo: 'Título',
    dados: dados
  },
  data: {
    // Dados adicionais
  },
  onClose: (options) => {
    if (options.data) {
      // Processar dados retornados
    }
  }
})
```

### Com Configurações

```vue
dialog.open(Componente, {
  props: {
    titulo: 'Dialog'
  },
  modal: true,
  draggable: true,
  resizable: true,
  position: 'center'
})
```

## Métodos do useDialog

- `open(component, options)` - Abre diálogo
- `close()` - Fecha diálogo atual

## Casos de Uso

- Diálogos dinâmicos
- Modais programáticos
- Componentes reutilizáveis
- Dialogs sob demanda

## Referências

- [Documentação Oficial](https://primevue.org/dynamicdialog)
- [API Reference](https://primevue.org/api/dynamicdialog)
