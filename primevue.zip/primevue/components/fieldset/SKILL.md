# PrimeVue Fieldset Component

Componente para agrupar campos com toggle de expansão.

## Import

```javascript
import Fieldset from 'primevue/fieldset';
```

## Uso Básico

```vue
<Fieldset legend="Título" :toggleable="true">
  <p>Conteúdo</p>
</Fieldset>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `legend` | string | Título do fieldset |
| `toggleable` | boolean | Permite expandir/colapsar |
| `collapsed` | boolean | Estado inicial colapsado |

## Exemplos

### Básico

```vue
<Fieldset legend="Informações Pessoais">
  <InputText v-model="nome" placeholder="Nome" />
  <InputText v-model="email" placeholder="Email" />
</Fieldset>
```

### Com Toggle

```vue
<Fieldset legend="Configurações Avançadas" :toggleable="true">
  <InputText v-model="config" />
</Fieldset>
```

### Inicialmente Colapsado

```vue
<Fieldset 
  legend="Detalhes" 
  :toggleable="true"
  :collapsed="true"
>
  <p>Conteúdo oculto inicialmente</p>
</Fieldset>
```

### Múltiplos Fieldsets

```vue
<div class="flex flex-column gap-3">
  <Fieldset legend="Dados Básicos">
    <InputText v-model="nome" />
  </Fieldset>
  
  <Fieldset legend="Endereço" :toggleable="true">
    <InputText v-model="endereco" />
  </Fieldset>
</div>
```

### Com Template Customizado

```vue
<Fieldset>
  <template #legend>
    <div class="flex items-center gap-2">
      <i class="pi pi-user"></i>
      <span>Usuário</span>
    </div>
  </template>
  <InputText v-model="usuario" />
</Fieldset>
```

## Casos de Uso

- Agrupar campos relacionados
- Formulários longos
- Configurações avançadas
- Organização de conteúdo

## Referências

- [Documentação Oficial](https://primevue.org/fieldset)
- [API Reference](https://primevue.org/api/fieldset)
