# PrimeVue Card Component

Componente de card do PrimeVue para exibir conteúdo agrupado.

## Import

```javascript
import Card from 'primevue/card';
```

## Uso Básico

```vue
<Card>
  <template #title>Título</template>
  <template #content>
    <p>Conteúdo do card</p>
  </template>
</Card>
```

## Slots

| Slot | Descrição |
|------|-----------|
| `title` | Título do card |
| `subtitle` | Subtítulo |
| `content` | Conteúdo principal |
| `footer` | Rodapé |

## Exemplos

### Básico

```vue
<Card>
  <template #title>Meu Card</template>
  <template #content>
    <p>Conteúdo aqui</p>
  </template>
</Card>
```

### Com Subtítulo e Rodapé

```vue
<Card>
  <template #title>Título</template>
  <template #subtitle>Subtítulo</template>
  <template #content>
    <p>Conteúdo principal</p>
  </template>
  <template #footer>
    <Button label="Ação" />
  </template>
</Card>
```

### Card Simples

```vue
<Card>
  <p>Card sem título, apenas conteúdo</p>
</Card>
```

### Card com Ações

```vue
<Card>
  <template #title>
    <div class="flex justify-between items-center">
      <span>Produto</span>
      <Button icon="pi pi-ellipsis-v" text />
    </div>
  </template>
  <template #content>
    <p>Descrição do produto</p>
  </template>
  <template #footer>
    <div class="flex gap-2">
      <Button label="Editar" />
      <Button label="Deletar" severity="danger" />
    </div>
  </template>
</Card>
```

## Referências

- [Documentação Oficial](https://primevue.org/card)
- [API Reference](https://primevue.org/api/card)
