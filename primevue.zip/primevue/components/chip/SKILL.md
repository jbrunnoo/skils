# PrimeVue Chip Component

Componente de chip/tag do PrimeVue.

## Import

```javascript
import Chip from 'primevue/chip';
```

## Uso Básico

```vue
<Chip label="Tag" />
<Chip label="Removível" removable />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `label` | string | Texto do chip |
| `icon` | string | Ícone |
| `image` | string | Imagem |
| `removable` | boolean | Permite remover |
| `severity` | string | Severidade |

## Exemplos

### Básico

```vue
<Chip label="Vue.js" />
```

### Removível

```vue
<Chip label="Remover" removable @remove="onRemove" />
```

### Com Ícone

```vue
<Chip label="Admin" icon="pi pi-user" />
```

## Referências

- [Documentação Oficial](https://primevue.org/chip)
- [API Reference](https://primevue.org/api/chip)
