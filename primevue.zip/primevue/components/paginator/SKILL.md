# PrimeVue Paginator Component

Componente de paginação para dividir conteúdo em páginas.

## Import

```javascript
import Paginator from 'primevue/paginator';
```

## Uso Básico

```vue
<Paginator 
  :rows="10" 
  :totalRecords="100" 
  @page="onPage" 
/>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `rows` | number | Itens por página |
| `totalRecords` | number | Total de registros |
| `first` | number | Primeiro item (v-model:first) |
| `rowsPerPageOptions` | array | Opções de itens por página |
| `template` | string | Template customizado |
| `alwaysShow` | boolean | Sempre mostra (mesmo com 1 página) |

## Exemplos

### Básico

```vue
<template>
  <Paginator 
    :rows="10" 
    :totalRecords="total" 
    @page="onPageChange"
  />
  <DataTable :value="paginatedData" />
</template>

<script setup>
const total = ref(100)
const paginatedData = ref([])

const onPageChange = (event) => {
  // event.first = primeiro item
  // event.rows = itens por página
  // event.page = página atual
  // event.pageCount = total de páginas
  
  carregarDados(event.first, event.rows)
}
</script>
```

### Com Opções de Itens por Página

```vue
<Paginator 
  :rows="10" 
  :totalRecords="100"
  :rowsPerPageOptions="[10, 20, 50, 100]"
  @page="onPage"
/>
```

### Integrado com DataTable

```vue
<template>
  <DataTable 
    :value="produtos" 
    paginator
    :rows="10"
    :totalRecords="total"
    @page="onPage"
  >
    <Column field="nome" header="Nome" />
  </DataTable>
</template>
```

### Com Template Customizado

```vue
<Paginator 
  :rows="10" 
  :totalRecords="100"
  template="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
/>
```

## Eventos

```vue
<Paginator 
  :rows="10" 
  :totalRecords="100"
  @page="onPage"
  @update:first="onFirstChange"
/>
```

## Casos de Uso

- Paginação de tabelas
- Listagem de resultados
- Navegação de conteúdo
- Controle de exibição de dados

## Referências

- [Documentação Oficial](https://primevue.org/paginator)
- [API Reference](https://primevue.org/api/paginator)
