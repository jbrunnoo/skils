# PrimeVue Toast Component

Componente de toast/notificação do PrimeVue.

## Import

```javascript
import Toast from 'primevue/toast';
import { useToast } from 'primevue/usetoast';
```

## Uso Básico

```vue
<template>
  <Toast />
  <Button @click="show" label="Mostrar Toast" />
</template>

<script setup>
import { useToast } from 'primevue/usetoast'
const toast = useToast()

const show = () => {
  toast.add({ severity: 'success', summary: 'Sucesso', detail: 'Operação realizada', life: 3000 })
}
</script>
```

## Métodos do useToast

| Método | Descrição |
|--------|-----------|
| `add(message)` | Adiciona toast |
| `remove(message)` | Remove toast |
| `clear()` | Limpa todos |

## Exemplos

### Tipos de Toast

```vue
toast.add({ severity: 'success', summary: 'Sucesso', detail: 'Mensagem' })
toast.add({ severity: 'info', summary: 'Info', detail: 'Mensagem' })
toast.add({ severity: 'warn', summary: 'Aviso', detail: 'Mensagem' })
toast.add({ severity: 'error', summary: 'Erro', detail: 'Mensagem' })
```

## Referências

- [Documentação Oficial](https://primevue.org/toast)
- [API Reference](https://primevue.org/api/toast)
