# PrimeVue Stepper Component

Componente de stepper (passos) do PrimeVue. **BREAKING CHANGE v4**: `Steps` foi substituído por `Stepper`.

## Import

```javascript
import Stepper from 'primevue/stepper';
import StepList from 'primevue/steplist';
import Step from 'primevue/step';
import StepPanels from 'primevue/steppanels';
import StepPanel from 'primevue/steppanel';
import StepItem from 'primevue/stepitem';
```

## Uso Básico

```vue
<Stepper v-model:value="passoAtivo">
  <StepList>
    <StepItem>
      <Step value="1">Passo 1</Step>
      <StepPanel value="1">Conteúdo 1</StepPanel>
    </StepItem>
    <StepItem>
      <Step value="2">Passo 2</Step>
      <StepPanel value="2">Conteúdo 2</StepPanel>
    </StepItem>
  </StepList>
</Stepper>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | any | Passo ativo (v-model:value) |
| `orientation` | string | "horizontal" ou "vertical" |

## Exemplos

### Básico Horizontal

```vue
<template>
  <Stepper v-model:value="passo">
    <StepList>
      <StepItem>
        <Step value="1">Informações</Step>
        <StepPanel value="1">Conteúdo passo 1</StepPanel>
      </StepItem>
      <StepItem>
        <Step value="2">Pagamento</Step>
        <StepPanel value="2">Conteúdo passo 2</StepPanel>
      </StepItem>
      <StepItem>
        <Step value="3">Confirmação</Step>
        <StepPanel value="3">Conteúdo passo 3</StepPanel>
      </StepItem>
    </StepList>
  </Stepper>
</template>

<script setup>
const passo = ref(1)
</script>
```

### Vertical (Importante: Use StepItem)

```vue
<Stepper v-model:value="passo" orientation="vertical">
  <StepList>
    <!-- ✅ CORRETO: Sempre envolva Step e StepPanel em StepItem -->
    <StepItem>
      <Step value="1">Passo 1</Step>
      <StepPanel value="1">Conteúdo 1</StepPanel>
    </StepItem>
    <StepItem>
      <Step value="2">Passo 2</Step>
      <StepPanel value="2">Conteúdo 2</StepPanel>
    </StepItem>
  </StepList>
</Stepper>
```

## Migração de Steps (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<Steps :model="items" />

<!-- v4 (CORRETO) -->
<Stepper v-model:value="activeStep">
  <StepList>
    <StepItem>
      <Step value="1">Passo 1</Step>
      <StepPanel value="1">Conteúdo</StepPanel>
    </StepItem>
  </StepList>
</Stepper>
```

## Referências

- [Documentação Oficial](https://primevue.org/stepper)
- [API Reference](https://primevue.org/api/stepper)
