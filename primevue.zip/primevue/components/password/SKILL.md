# PrimeVue Password Component

Componente de input de senha do PrimeVue com toggle de visibilidade.

## Import

```javascript
import Password from 'primevue/password';
```

## Uso Básico

```vue
<Password v-model="senha" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | string | Valor (v-model) |
| `feedback` | boolean | Mostra feedback de força |
| `toggleMask` | boolean | Mostra botão toggle |
| `promptLabel` | string | Label do prompt |
| `weakLabel` | string | Label fraco |
| `mediumLabel` | string | Label médio |
| `strongLabel` | string | Label forte |

## Exemplos

### Básico

```vue
<Password v-model="senha" />
```

### Com Feedback

```vue
<Password v-model="senha" :feedback="true" />
```

### Com Toggle

```vue
<Password v-model="senha" :toggleMask="true" />
```

## Referências

- [Documentação Oficial](https://primevue.org/password)
- [API Reference](https://primevue.org/api/password)
