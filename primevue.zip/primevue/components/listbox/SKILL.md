# PrimeVue Listbox Component

Componente de lista de seleção (alternativa ao Select).

## Import

```javascript
import Listbox from 'primevue/listbox';
```

## Uso Básico

```vue
<Listbox v-model="selected" :options="options" optionLabel="name" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `options` | array | Opções disponíveis |
| `optionLabel` | string | Propriedade para label |
| `optionValue` | string | Propriedade para value |
| `optionDisabled` | string | Propriedade para desabilitar |
| `multiple` | boolean | Seleção múltipla |
| `filter` | boolean | Habilita filtro |
| `filterPlaceholder` | string | Placeholder do filtro |
| `listStyle` | string | Estilo da lista (ex: "height: 200px") |

## Exemplos

### Básico

```vue
<template>
  <Listbox 
    v-model="selecionado" 
    :options="cidades" 
    optionLabel="name"
    placeholder="Selecione uma cidade"
  />
</template>

<script setup>
const selecionado = ref(null)
const cidades = ref([
  { name: 'São Paulo', code: 'SP' },
  { name: 'Rio de Janeiro', code: 'RJ' },
  { name: 'Belo Horizonte', code: 'BH' }
])
</script>
```

### Com Filtro

```vue
<Listbox 
  v-model="selecionado" 
  :options="opcoes" 
  optionLabel="name"
  filter
  filterPlaceholder="Buscar..."
/>
```

### Seleção Múltipla

```vue
<template>
  <Listbox 
    v-model="selecionados" 
    :options="opcoes" 
    optionLabel="name"
    multiple
  />
</template>

<script setup>
const selecionados = ref([])
</script>
```

### Com Altura Fixa

```vue
<Listbox 
  v-model="selecionado" 
  :options="opcoes" 
  optionLabel="name"
  listStyle="height: 200px"
/>
```

### Com Template Customizado

```vue
<Listbox v-model="selecionado" :options="opcoes" optionLabel="name">
  <template #option="slotProps">
    <div class="flex items-center gap-2">
      <i :class="slotProps.option.icon"></i>
      <span>{{ slotProps.option.name }}</span>
    </div>
  </template>
</Listbox>
```

## Diferença do Select

- Listbox mostra todas as opções visíveis
- Select mostra dropdown
- Listbox melhor para poucas opções
- Select melhor para muitas opções

## Referências

- [Documentação Oficial](https://primevue.org/listbox)
- [API Reference](https://primevue.org/api/listbox)
