# PrimeVue Popover Component

Componente de popover do PrimeVue. **BREAKING CHANGE v4**: `OverlayPanel` foi renomeado para `Popover`.

## Import

```javascript
import Popover from 'primevue/popover';
```

## Uso Básico

```vue
<Popover>
  <template #target="{ toggle }">
    <Button @click="toggle" label="Abrir" />
  </template>
  <template #content>
    <p>Conteúdo do popover</p>
  </template>
</Popover>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `dismissable` | boolean | Fecha ao clicar fora |
| `appendTo` | string | Onde anexar (default: "body") |

## Exemplos

### Básico

```vue
<template>
  <Popover>
    <template #target="{ toggle }">
      <Button @click="toggle" label="Mostrar Popover" />
    </template>
    <template #content>
      <div class="p-3">
        <h4>Título</h4>
        <p>Conteúdo do popover</p>
      </div>
    </template>
  </Popover>
</template>
```

### Com Menu

```vue
<Popover>
  <template #target="{ toggle }">
    <Button icon="pi pi-ellipsis-v" @click="toggle" />
  </template>
  <template #content>
    <Menu :model="menuItems" />
  </template>
</Popover>
```

## Migração de OverlayPanel (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<OverlayPanel>
  <Button label="Abrir" />
  <template #content>Conteúdo</template>
</OverlayPanel>

<!-- v4 (CORRETO) -->
<Popover>
  <template #target="{ toggle }">
    <Button @click="toggle" label="Abrir" />
  </template>
  <template #content>Conteúdo</template>
</Popover>
```

## Referências

- [Documentação Oficial](https://primevue.org/popover)
- [API Reference](https://primevue.org/api/popover)
