# PrimeVue KeyFilter Directive

Diretiva para filtrar teclas permitidas em inputs.

## Import

```javascript
import KeyFilter from 'primevue/keyfilter';
```

## Configuração

```javascript
app.directive('keyfilter', KeyFilter);
```

## Padrões Disponíveis

| Padrão | Descrição |
|--------|-----------|
| `pint` | Apenas números inteiros positivos |
| `int` | Números inteiros (positivos e negativos) |
| `pnum` | Números positivos (inteiros e decimais) |
| `num` | Números (inteiros e decimais, positivos e negativos) |
| `hex` | Hexadecimal |
| `email` | Email |
| `alpha` | Apenas letras |
| `alphanum` | Letras e números |

## Uso Básico

```vue
<InputText v-model="valor" v-keyfilter="'int'" />
```

## Exemplos

### Apenas Números

```vue
<InputText v-model="idade" v-keyfilter="'pint'" placeholder="Idade" />
```

### Números com Decimais

```vue
<InputText v-model="preco" v-keyfilter="'num'" placeholder="Preço" />
```

### Apenas Letras

```vue
<InputText v-model="nome" v-keyfilter="'alpha'" placeholder="Nome" />
```

### Letras e Números

```vue
<InputText v-model="codigo" v-keyfilter="'alphanum'" placeholder="Código" />
```

### Email

```vue
<InputText v-model="email" v-keyfilter="'email'" placeholder="Email" />
```

### Regex Customizado

```vue
<InputText v-model="valor" v-keyfilter="/[0-9]/" />
```

## Casos de Uso

- Validação de entrada
- Filtro de caracteres
- Inputs numéricos
- Campos específicos

## Referências

- [Documentação Oficial](https://primevue.org/keyfilter)
- [API Reference](https://primevue.org/api/keyfilter)
