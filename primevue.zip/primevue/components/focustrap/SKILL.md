# PrimeVue FocusTrap Directive

Diretiva para prender o foco dentro de um elemento (útil em modais).

## Import

```javascript
import FocusTrap from 'primevue/focustrap';
```

## Configuração

```javascript
app.directive('focustrap', FocusTrap);
```

## Uso Básico

```vue
<div v-focustrap>
  <input />
  <button>Fechar</button>
</div>
```

## Exemplos

### Em Modal

```vue
<template>
  <Dialog v-model:visible="show">
    <div v-focustrap>
      <InputText v-model="nome" />
      <InputText v-model="email" />
      <Button label="Salvar" />
      <Button label="Cancelar" @click="show = false" />
    </div>
  </Dialog>
</template>
```

### Em Drawer

```vue
<Drawer v-model:visible="show">
  <div v-focustrap>
    <InputText v-model="busca" />
    <Menu :model="items" />
  </div>
</Drawer>
```

### Com Opções

```vue
<div v-focustrap="{ autoFocus: true }">
  <input />
  <button>OK</button>
</div>
```

## Casos de Uso

- Modais e diálogos
- Drawers e sidebars
- Popups
- Formulários modais

## Referências

- [Documentação Oficial](https://primevue.org/focustrap)
- [API Reference](https://primevue.org/api/focustrap)
