# PrimeVue SplitButton Component

Botão com menu dropdown integrado.

## Import

```javascript
import SplitButton from 'primevue/splitbutton';
```

## Uso Básico

```vue
<SplitButton label="Salvar" icon="pi pi-check" :model="menuItems" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `label` | string | Texto do botão |
| `icon` | string | Ícone do botão |
| `model` | array | Itens do menu dropdown |
| `severity` | string | Severidade do botão |
| `disabled` | boolean | Desabilita |

## Exemplos

### Básico

```vue
<template>
  <SplitButton 
    label="Salvar" 
    icon="pi pi-check" 
    :model="items"
    @click="salvar"
  />
</template>

<script setup>
const items = ref([
  {
    label: 'Salvar como rascunho',
    icon: 'pi pi-file',
    command: () => salvarRascunho()
  },
  {
    label: 'Exportar',
    icon: 'pi pi-download',
    command: () => exportar()
  }
])

const salvar = () => {
  // Ação do botão principal
  salvarDocumento()
}
</script>
```

### Com Severidade

```vue
<SplitButton 
  label="Deletar" 
  icon="pi pi-trash" 
  :model="items"
  severity="danger"
/>
```

### Apenas com Ícone

```vue
<SplitButton 
  icon="pi pi-cog" 
  :model="items"
  :label="null"
/>
```

### Com Menu Customizado

```vue
<SplitButton label="Ações" :model="items">
  <template #item="slotProps">
    <div class="flex items-center gap-2">
      <i :class="slotProps.item.icon"></i>
      <span>{{ slotProps.item.label }}</span>
    </div>
  </template>
</SplitButton>
```

## Casos de Uso

- Botões com ações secundárias
- Menu de opções
- Ações com alternativas
- Botões com dropdown

## Referências

- [Documentação Oficial](https://primevue.org/splitbutton)
- [API Reference](https://primevue.org/api/splitbutton)
