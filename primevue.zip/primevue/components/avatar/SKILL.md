# PrimeVue Avatar Component

Componente de avatar do PrimeVue.

## Import

```javascript
import Avatar from 'primevue/avatar';
```

## Uso Básico

```vue
<Avatar label="JD" />
<Avatar image="path/to/image.jpg" />
<Avatar icon="pi pi-user" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `label` | string | Texto do avatar |
| `image` | string | URL da imagem |
| `icon` | string | Ícone |
| `size` | string | Tamanho: "normal", "large", "xlarge" |
| `shape` | string | Forma: "circle", "square" |

## Exemplos

### Com Label

```vue
<Avatar label="JD" />
```

### Com Imagem

```vue
<Avatar image="https://example.com/user.jpg" />
```

### Com Ícone

```vue
<Avatar icon="pi pi-user" />
```

## Referências

- [Documentação Oficial](https://primevue.org/avatar)
- [API Reference](https://primevue.org/api/avatar)
