# PrimeVue InputGroup Component

Grupo de inputs com addons (prefixos e sufixos).

## Import

```javascript
import InputGroup from 'primevue/inputgroup';
import InputGroupAddon from 'primevue/inputgroupaddon';
```

## Uso Básico

```vue
<InputGroup>
  <InputGroupAddon>
    <i class="pi pi-user" />
  </InputGroupAddon>
  <InputText v-model="username" />
</InputGroup>
```

## Exemplos

### Com Ícone Prefixo

```vue
<InputGroup>
  <InputGroupAddon>
    <i class="pi pi-user" />
  </InputGroupAddon>
  <InputText v-model="username" placeholder="Usuário" />
</InputGroup>
```

### Com Ícone Sufixo

```vue
<InputGroup>
  <InputText v-model="senha" type="password" />
  <InputGroupAddon>
    <i class="pi pi-eye" />
  </InputGroupAddon>
</InputGroup>
```

### Com Ambos

```vue
<InputGroup>
  <InputGroupAddon>
    <i class="pi pi-dollar" />
  </InputGroupAddon>
  <InputText v-model="preco" />
  <InputGroupAddon>
    <i class="pi pi-check" />
  </InputGroupAddon>
</InputGroup>
```

### Com Botão

```vue
<InputGroup>
  <InputText v-model="busca" placeholder="Buscar..." />
  <InputGroupAddon>
    <Button icon="pi pi-search" />
  </InputGroupAddon>
</InputGroup>
```

### Com Texto

```vue
<InputGroup>
  <InputGroupAddon>R$</InputGroupAddon>
  <InputText v-model="valor" />
  <InputGroupAddon>,00</InputGroupAddon>
</InputGroup>
```

## Casos de Uso

- Inputs com ícones
- Formatação de valores
- Botões integrados
- Prefixos/sufixos visuais

## Referências

- [Documentação Oficial](https://primevue.org/inputgroup)
- [API Reference](https://primevue.org/api/inputgroup)
