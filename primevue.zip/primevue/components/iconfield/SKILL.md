# PrimeVue IconField Component

Wrapper para inputs com ícones.

## Import

```javascript
import IconField from 'primevue/iconfield';
import InputIcon from 'primevue/inputicon';
```

## Uso Básico

```vue
<IconField>
  <InputIcon class="pi pi-search" />
  <InputText placeholder="Buscar" />
</IconField>
```

## Referências

- [Documentação Oficial](https://primevue.org/iconfield)
- [API Reference](https://primevue.org/api/iconfield)
