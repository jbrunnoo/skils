# PrimeVue DatePicker Component

Componente de seleção de data do PrimeVue. **BREAKING CHANGE v4**: `Calendar` foi renomeado para `DatePicker`.

## Import

```javascript
import DatePicker from 'primevue/datepicker';
```

## Uso Básico

```vue
<DatePicker v-model="date" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | Date/string | Data selecionada (v-model) |
| `dateFormat` | string | Formato: "dd/mm/yy", "mm/dd/yy", etc. |
| `showIcon` | boolean | Mostra ícone de calendário |
| `showTime` | boolean | Inclui seletor de hora |
| `showSeconds` | boolean | Inclui segundos |
| `minDate` | Date | Data mínima |
| `maxDate` | Date | Data máxima |
| `disabledDates` | array | Datas desabilitadas |
| `disabledDays` | array | Dias da semana desabilitados |
| `selectionMode` | string | "single", "multiple", "range" |
| `placeholder` | string | Placeholder |

## Exemplos

### Básico

```vue
<template>
  <DatePicker v-model="data" />
</template>

<script setup>
import { ref } from 'vue'
const data = ref(null)
</script>
```

### Com Formato Brasileiro

```vue
<DatePicker 
  v-model="data" 
  dateFormat="dd/mm/yy"
  placeholder="dd/mm/aaaa"
/>
```

### Com Ícone

```vue
<DatePicker v-model="data" showIcon />
```

### Com Hora

```vue
<DatePicker v-model="dataHora" showTime />
```

### Seleção de Período

```vue
<DatePicker 
  v-model="periodo" 
  selectionMode="range"
  dateFormat="dd/mm/yy"
/>
```

### Múltiplas Datas

```vue
<DatePicker 
  v-model="datas" 
  selectionMode="multiple"
  dateFormat="dd/mm/yy"
/>
```

### Com Limites

```vue
<DatePicker 
  v-model="data"
  :minDate="new Date()"
  :maxDate="new Date(2025, 11, 31)"
/>
```

### Desabilitar Finais de Semana

```vue
<DatePicker 
  v-model="data"
  :disabledDays="[0, 6]"
/>
```

## Migração de Calendar (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<Calendar v-model="date" />

<!-- v4 (CORRETO) -->
<DatePicker v-model="date" />
```

## Referências

- [Documentação Oficial](https://primevue.org/datepicker)
- [API Reference](https://primevue.org/api/datepicker)
