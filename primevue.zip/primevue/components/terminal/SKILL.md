# PrimeVue Terminal Component

Componente de terminal/console interativo.

## Import

```javascript
import Terminal from 'primevue/terminal';
import TerminalService from 'primevue/terminalservice';
```

## Uso Básico

```vue
<Terminal welcomeMessage="Bem-vindo" prompt="$" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `welcomeMessage` | string | Mensagem de boas-vindas |
| `prompt` | string | Prompt do terminal |

## Exemplos

### Básico

```vue
<template>
  <Terminal 
    welcomeMessage="Terminal Interativo" 
    prompt="$"
    @command="onCommand"
  />
</template>

<script setup>
import { useTerminal } from 'primevue/useterminal'
const terminal = useTerminal()

const onCommand = (text) => {
  const response = processarComando(text)
  terminal.emit('response', response)
}
</script>
```

### Com Comandos Customizados

```vue
<template>
  <Terminal 
    welcomeMessage="Meu Terminal" 
    prompt=">"
    @command="executar"
  />
</template>

<script setup>
const executar = (comando) => {
  switch(comando) {
    case 'help':
      terminal.emit('response', 'Comandos disponíveis: help, clear, date')
      break
    case 'clear':
      terminal.emit('clear')
      break
    default:
      terminal.emit('response', `Comando não encontrado: ${comando}`)
  }
}
</script>
```

## Casos de Uso

- Terminal interativo
- Console de comandos
- Interface de linha de comando
- Debug tools

## Referências

- [Documentação Oficial](https://primevue.org/terminal)
- [API Reference](https://primevue.org/api/terminal)
