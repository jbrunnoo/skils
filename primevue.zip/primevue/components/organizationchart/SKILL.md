# PrimeVue OrganizationChart Component

Gráfico organizacional para exibir hierarquia.

## Import

```javascript
import OrganizationChart from 'primevue/organizationchart';
```

## Uso Básico

```vue
<OrganizationChart :value="data" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Dados hierárquicos |
| `collapsible` | boolean | Permite colapsar nós |
| `selectionMode` | string | "single" ou "multiple" |

## Exemplos

### Básico

```vue
<template>
  <OrganizationChart :value="organizacao" />
</template>

<script setup>
const organizacao = ref({
  data: {
    label: 'CEO',
    expanded: true
  },
  children: [
    {
      data: {
        label: 'CTO',
        expanded: true
      },
      children: [
        { data: { label: 'Dev Team 1' } },
        { data: { label: 'Dev Team 2' } }
      ]
    },
    {
      data: {
        label: 'CFO',
        expanded: true
      },
      children: [
        { data: { label: 'Finance Team' } }
      ]
    }
  ]
})
</script>
```

### Com Colapso

```vue
<OrganizationChart :value="organizacao" :collapsible="true" />
```

### Com Template Customizado

```vue
<OrganizationChart :value="organizacao">
  <template #node="slotProps">
    <div class="p-3 border">
      <h4>{{ slotProps.node.data.label }}</h4>
      <p>{{ slotProps.node.data.cargo }}</p>
    </div>
  </template>
</OrganizationChart>
```

## Estrutura de Dados

```typescript
interface OrgChartNode {
  data: {
    label: string
    expanded?: boolean
    [key: string]: any
  }
  children?: OrgChartNode[]
}
```

## Casos de Uso

- Organograma empresarial
- Hierarquia de equipes
- Estrutura organizacional
- Árvore de departamentos

## Referências

- [Documentação Oficial](https://primevue.org/organizationchart)
- [API Reference](https://primevue.org/api/organizationchart)
