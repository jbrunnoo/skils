# PrimeVue Tag Component

Componente de tag/label para exibir informações categorizadas.

## Import

```javascript
import Tag from 'primevue/tag';
```

## Uso Básico

```vue
<Tag value="Novo" severity="success" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | string | Texto da tag |
| `severity` | string | "success", "info", "warn", "danger", "secondary", "contrast" |
| `icon` | string | Ícone |
| `rounded` | boolean | Tag arredondada |

## Exemplos

### Básico

```vue
<Tag value="Novo" />
```

### Com Severidade

```vue
<Tag value="Ativo" severity="success" />
<Tag value="Pendente" severity="warn" />
<Tag value="Inativo" severity="danger" />
<Tag value="Info" severity="info" />
```

### Com Ícone

```vue
<Tag value="Premium" icon="pi pi-star" severity="success" />
```

### Arredondado

```vue
<Tag value="Novo" severity="success" rounded />
```

### Em Tabela

```vue
<Column field="status" header="Status">
  <template #body="slotProps">
    <Tag 
      :value="slotProps.data.status" 
      :severity="getSeverity(slotProps.data.status)"
    />
  </template>
</Column>
```

## Casos de Uso

- Status de itens
- Categorias
- Labels informativos
- Badges de estado

## Referências

- [Documentação Oficial](https://primevue.org/tag)
- [API Reference](https://primevue.org/api/tag)
