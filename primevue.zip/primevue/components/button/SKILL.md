# PrimeVue Button Component

Componente de botão do PrimeVue com suporte a ícones, badges e temas.

## Import

```javascript
import Button from 'primevue/button';
```

## Uso Básico

```vue
<Button label="Enviar" />
<Button label="Cancelar" icon="pi pi-times" />
<Button icon="pi pi-check" aria-label="Confirmar" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `label` | string | Texto do botão |
| `icon` | string | Ícone (ex: "pi pi-check") |
| `disabled` | boolean | Desabilita o botão |
| `loading` | boolean | Mostra estado de carregamento |
| `badge` | string | Badge no botão |
| `badgeSeverity` | string | Severidade do badge |
| `variant` | string | Variante: "primary", "secondary", "outlined", etc. |
| `severity` | string | Severidade: "success", "info", "warn", "danger" |
| `size` | string | Tamanho: "small", "large" |
| `rounded` | boolean | Botão arredondado |
| `text` | boolean | Estilo texto |
| `link` | boolean | Estilo link |
| `plain` | boolean | Estilo plain |

## Exemplos

### Botão com Ícone

```vue
<Button label="Salvar" icon="pi pi-check" />
<Button icon="pi pi-trash" aria-label="Deletar" />
```

### Botão com Badge

```vue
<Button label="Mensagens" badge="5" />
<Button label="Notificações" icon="pi pi-bell" badge="3" badgeSeverity="danger" />
```

### Variantes

```vue
<Button label="Primary" variant="primary" />
<Button label="Secondary" variant="secondary" />
<Button label="Outlined" variant="outlined" />
<Button label="Text" text />
<Button label="Link" link />
```

### Severidades

```vue
<Button label="Success" severity="success" />
<Button label="Info" severity="info" />
<Button label="Warning" severity="warn" />
<Button label="Danger" severity="danger" />
```

### Estados

```vue
<Button label="Desabilitado" disabled />
<Button label="Carregando" loading />
<Button label="Arredondado" rounded />
```

### Button Group

```vue
<ButtonGroup>
    <Button label="Salvar" icon="pi pi-check" />
    <Button label="Deletar" icon="pi pi-trash" />
    <Button label="Cancelar" icon="pi pi-times" />
</ButtonGroup>
```

## Acessibilidade

- Use `aria-label` para botões apenas com ícone
- Suporte completo a teclado (Tab, Enter, Space)
- Compatível com leitores de tela (WCAG 2.1 AA)

## Referências

- [Documentação Oficial](https://primevue.org/button)
- [API Reference](https://primevue.org/api/button)
