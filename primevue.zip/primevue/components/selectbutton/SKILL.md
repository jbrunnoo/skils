# PrimeVue SelectButton Component

Botões de seleção múltipla (alternativa a radio buttons).

## Import

```javascript
import SelectButton from 'primevue/selectbutton';
```

## Uso Básico

```vue
<SelectButton v-model="selected" :options="options" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `options` | array | Opções disponíveis |
| `optionLabel` | string | Propriedade para label |
| `optionValue` | string | Propriedade para value |
| `multiple` | boolean | Seleção múltipla |
| `disabled` | boolean | Desabilita |

## Exemplos

### Básico

```vue
<template>
  <SelectButton v-model="selecionado" :options="opcoes" />
</template>

<script setup>
const selecionado = ref('opcao1')
const opcoes = ref(['opcao1', 'opcao2', 'opcao3'])
</script>
```

### Com Objetos

```vue
<template>
  <SelectButton 
    v-model="selecionado" 
    :options="opcoes" 
    optionLabel="name"
    optionValue="value"
  />
</template>

<script setup>
const selecionado = ref('view')
const opcoes = ref([
  { name: 'Lista', value: 'list', icon: 'pi pi-list' },
  { name: 'Grid', value: 'grid', icon: 'pi pi-th-large' },
  { name: 'Card', value: 'card', icon: 'pi pi-id-card' }
])
</script>
```

### Seleção Múltipla

```vue
<template>
  <SelectButton 
    v-model="selecionados" 
    :options="opcoes" 
    :multiple="true"
  />
</template>

<script setup>
const selecionados = ref(['op1', 'op2'])
const opcoes = ref(['op1', 'op2', 'op3'])
</script>
```

### Com Ícones

```vue
<SelectButton v-model="selecionado" :options="opcoes">
  <template #option="slotProps">
    <i :class="slotProps.option.icon"></i>
    <span>{{ slotProps.option.name }}</span>
  </template>
</SelectButton>
```

## Casos de Uso

- Seleção de visualização
- Filtros de tipo
- Alternância de modos
- Seleção de opções

## Referências

- [Documentação Oficial](https://primevue.org/selectbutton)
- [API Reference](https://primevue.org/api/selectbutton)
