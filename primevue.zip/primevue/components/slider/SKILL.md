# PrimeVue Slider Component

Componente slider para seleção de valores numéricos em um range.

## Import

```javascript
import Slider from 'primevue/slider';
```

## Uso Básico

```vue
<Slider v-model="value" :min="0" :max="100" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | number/array | Valor(s) (v-model) |
| `min` | number | Valor mínimo |
| `max` | number | Valor máximo |
| `step` | number | Incremento |
| `range` | boolean | Modo range (dois valores) |
| `orientation` | string | "horizontal" ou "vertical" |
| `disabled` | boolean | Desabilita |
| `animate` | boolean | Animação ao mover |

## Exemplos

### Básico

```vue
<template>
  <Slider v-model="valor" :min="0" :max="100" />
  <p>Valor: {{ valor }}</p>
</template>

<script setup>
const valor = ref(50)
</script>
```

### Range (Dois Valores)

```vue
<template>
  <Slider v-model="range" :min="0" :max="100" range />
  <p>De {{ range[0] }} até {{ range[1] }}</p>
</template>

<script setup>
const range = ref([20, 80])
</script>
```

### Com Step

```vue
<Slider v-model="valor" :min="0" :max="100" :step="5" />
```

### Vertical

```vue
<Slider 
  v-model="valor" 
  :min="0" 
  :max="100" 
  orientation="vertical"
  style="height: 200px"
/>
```

### Com Labels

```vue
<template>
  <div class="flex flex-column gap-2">
    <label>Preço: R$ {{ preco }}</label>
    <Slider v-model="preco" :min="0" :max="1000" />
  </div>
</template>
```

### Com Input

```vue
<template>
  <div class="flex gap-2 align-items-center">
    <InputNumber v-model="valor" :min="0" :max="100" />
    <Slider v-model="valor" :min="0" :max="100" style="flex: 1" />
  </div>
</template>
```

## Casos de Uso

- Filtros de preço
- Controles de volume/brightness
- Seleção de faixa etária
- Configurações de range

## Referências

- [Documentação Oficial](https://primevue.org/slider)
- [API Reference](https://primevue.org/api/slider)
