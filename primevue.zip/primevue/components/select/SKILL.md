# PrimeVue Select Component

Componente de seleção (anteriormente Dropdown) do PrimeVue. **BREAKING CHANGE v4**: `Dropdown` foi renomeado para `Select`.

## Import

```javascript
import Select from 'primevue/select';
```

## Uso Básico

```vue
<Select v-model="selected" :options="options" optionLabel="name" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `options` | array | Array de opções |
| `optionLabel` | string | Propriedade do objeto para label |
| `optionValue` | string | Propriedade do objeto para value |
| `optionDisabled` | string | Propriedade para desabilitar opção |
| `placeholder` | string | Placeholder |
| `disabled` | boolean | Desabilita o select |
| `filter` | boolean | Habilita filtro |
| `showClear` | boolean | Mostra botão limpar |
| `virtualScrollerOptions` | object | Opções de virtual scroll |

## Exemplos

### Básico com Array Simples

```vue
<template>
  <Select v-model="selected" :options="cidades" />
</template>

<script setup>
import { ref } from 'vue'
const selected = ref(null)
const cidades = ['São Paulo', 'Rio de Janeiro', 'Belo Horizonte']
</script>
```

### Com Objetos

```vue
<template>
  <Select 
    v-model="selected" 
    :options="paises" 
    optionLabel="name"
    optionValue="code"
    placeholder="Selecione um país"
  />
</template>

<script setup>
import { ref } from 'vue'
const selected = ref(null)
const paises = [
  { name: 'Brasil', code: 'BR' },
  { name: 'Argentina', code: 'AR' },
  { name: 'Chile', code: 'CL' }
]
</script>
```

### Com Filtro

```vue
<Select 
  v-model="selected" 
  :options="options" 
  optionLabel="name"
  filter
  placeholder="Buscar..."
/>
```

### Com Botão Limpar

```vue
<Select 
  v-model="selected" 
  :options="options" 
  optionLabel="name"
  showClear
  placeholder="Selecione..."
/>
```

### Com Ícone

```vue
<IconField>
  <InputIcon class="pi pi-map-marker" />
  <Select v-model="selected" :options="options" optionLabel="name" />
</IconField>
```

### Desabilitado

```vue
<Select v-model="selected" :options="options" disabled />
```

### Virtual Scroll (Grandes Listas)

```vue
<Select 
  v-model="selected" 
  :options="largeList" 
  optionLabel="name"
  :virtualScrollerOptions="{ itemSize: 38 }"
/>
```

## Acessibilidade

- Suporte completo a teclado
- Compatível com leitores de tela
- Use `aria-label` quando necessário

## Migração de Dropdown (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<Dropdown v-model="selected" :options="options" />

<!-- v4 (CORRETO) -->
<Select v-model="selected" :options="options" />
```

## Referências

- [Documentação Oficial](https://primevue.org/select)
- [API Reference](https://primevue.org/api/select)
