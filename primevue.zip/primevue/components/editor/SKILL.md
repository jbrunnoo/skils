# PrimeVue Editor Component

Editor WYSIWYG (baseado em Quill).

## Import

```javascript
import Editor from 'primevue/editor';
```

## Uso Básico

```vue
<Editor v-model="content" editorStyle="height: 320px" />
```

## Referências

- [Documentação Oficial](https://primevue.org/editor)
- [API Reference](https://primevue.org/api/editor)
