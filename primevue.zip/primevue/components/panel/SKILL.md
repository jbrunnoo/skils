# PrimeVue Panel Component

Painel de conteúdo com header e footer opcionais.

## Import

```javascript
import Panel from 'primevue/panel';
```

## Uso Básico

```vue
<Panel header="Título">
  <p>Conteúdo do painel</p>
</Panel>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `header` | string | Título do painel |
| `toggleable` | boolean | Permite expandir/colapsar |
| `collapsed` | boolean | Estado inicial colapsado |

## Exemplos

### Básico

```vue
<Panel header="Meu Painel">
  <p>Conteúdo aqui</p>
</Panel>
```

### Com Toggle

```vue
<Panel header="Painel Expansível" :toggleable="true">
  <p>Conteúdo que pode ser colapsado</p>
</Panel>
```

### Com Footer

```vue
<Panel header="Título">
  <template #content>
    <p>Conteúdo</p>
  </template>
  <template #footer>
    <Button label="Salvar" />
  </template>
</Panel>
```

### Com Ícone no Header

```vue
<Panel>
  <template #header>
    <div class="flex items-center gap-2">
      <i class="pi pi-info-circle"></i>
      <span>Informações</span>
    </div>
  </template>
  <p>Conteúdo</p>
</Panel>
```

### Múltiplos Painéis

```vue
<div class="flex flex-column gap-3">
  <Panel header="Painel 1">
    <p>Conteúdo 1</p>
  </Panel>
  <Panel header="Painel 2">
    <p>Conteúdo 2</p>
  </Panel>
</div>
```

## Casos de Uso

- Agrupar conteúdo relacionado
- Seções expansíveis
- Organização de informações
- Dashboards

## Referências

- [Documentação Oficial](https://primevue.org/panel)
- [API Reference](https://primevue.org/api/panel)
