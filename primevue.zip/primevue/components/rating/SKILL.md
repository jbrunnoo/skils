# PrimeVue Rating Component

Componente de avaliação com estrelas.

## Import

```javascript
import Rating from 'primevue/rating';
```

## Uso Básico

```vue
<Rating v-model="value" :stars="5" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | number | Valor (v-model) |
| `stars` | number | Número de estrelas (padrão: 5) |
| `cancel` | boolean | Permite cancelar avaliação |
| `readonly` | boolean | Somente leitura |
| `disabled` | boolean | Desabilita |
| `icon` | string | Ícone customizado |

## Exemplos

### Básico

```vue
<template>
  <Rating v-model="avaliacao" />
  <p>Avaliação: {{ avaliacao }}/5</p>
</template>

<script setup>
const avaliacao = ref(0)
</script>
```

### Com Cancelamento

```vue
<Rating v-model="avaliacao" :cancel="true" />
```

### Somente Leitura

```vue
<Rating v-model="avaliacao" :readonly="true" />
```

### Com Número de Estrelas

```vue
<Rating v-model="avaliacao" :stars="10" />
```

### Com Label

```vue
<template>
  <div class="flex flex-column gap-2">
    <label>Avalie este produto</label>
    <Rating v-model="avaliacao" />
    <span v-if="avaliacao > 0">Obrigado pela avaliação!</span>
  </div>
</template>
```

### Em Formulário

```vue
<template>
  <form @submit.prevent="salvar">
    <div class="field">
      <label>Avaliação</label>
      <Rating v-model="form.avaliacao" />
    </div>
    <Button type="submit" label="Enviar" />
  </form>
</template>
```

## Casos de Uso

- Avaliação de produtos
- Feedback de serviços
- Classificação de conteúdo
- Reviews e comentários

## Referências

- [Documentação Oficial](https://primevue.org/rating)
- [API Reference](https://primevue.org/api/rating)
