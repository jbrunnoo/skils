# PrimeVue SpeedDial Component

Botão de ações rápidas (FAB - Floating Action Button) com menu.

## Import

```javascript
import SpeedDial from 'primevue/speeddial';
```

## Uso Básico

```vue
<SpeedDial :model="items" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do menu |
| `direction` | string | Direção: "up", "down", "left", "right" |
| `transitionDelay` | number | Delay da transição |
| `type` | string | Tipo: "linear" ou "circle" |
| `radius` | number | Raio (tipo circle) |
| `mask` | boolean | Mostra máscara de fundo |

## Exemplos

### Básico

```vue
<template>
  <SpeedDial :model="items" />
</template>

<script setup>
const items = ref([
  {
    label: 'Adicionar',
    icon: 'pi pi-plus',
    command: () => adicionar()
  },
  {
    label: 'Editar',
    icon: 'pi pi-pencil',
    command: () => editar()
  },
  {
    label: 'Deletar',
    icon: 'pi pi-trash',
    command: () => deletar()
  }
])
</script>
```

### Direções

```vue
<SpeedDial :model="items" direction="up" />
<SpeedDial :model="items" direction="down" />
<SpeedDial :model="items" direction="left" />
<SpeedDial :model="items" direction="right" />
```

### Tipo Circle

```vue
<SpeedDial :model="items" type="circle" :radius="80" />
```

### Com Máscara

```vue
<SpeedDial :model="items" :mask="true" />
```

### Posicionamento

```vue
<SpeedDial 
  :model="items" 
  direction="up"
  style="position: fixed; bottom: 20px; right: 20px"
/>
```

## Casos de Uso

- Ações rápidas flutuantes
- Menu de ações principais
- FAB buttons
- Atalhos de ações

## Referências

- [Documentação Oficial](https://primevue.org/speeddial)
- [API Reference](https://primevue.org/api/speeddial)
