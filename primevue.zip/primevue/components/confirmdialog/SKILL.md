# PrimeVue ConfirmationDialog Component

Diálogo de confirmação usando o composable useConfirm.

## Import

```javascript
import ConfirmationDialog from 'primevue/confirmationdialog';
import { useConfirm } from 'primevue/useconfirm';
```

## Uso Básico

```vue
<template>
  <ConfirmationDialog />
  <Button @click="confirmar" label="Deletar" />
</template>

<script setup>
import { useConfirm } from 'primevue/useconfirm'
const confirm = useConfirm()

const confirmar = () => {
  confirm.require({
    message: 'Tem certeza que deseja deletar?',
    header: 'Confirmação',
    icon: 'pi pi-exclamation-triangle',
    accept: () => {
      // Ação ao confirmar
      deletar()
    },
    reject: () => {
      // Ação ao rejeitar (opcional)
    }
  })
}
</script>
```

## Exemplos

### Básico

```vue
<template>
  <ConfirmationDialog />
  <Button label="Deletar" @click="confirmarDelecao" />
</template>

<script setup>
const confirm = useConfirm()

const confirmarDelecao = () => {
  confirm.require({
    message: 'Esta ação não pode ser desfeita.',
    header: 'Confirmar Deleção',
    icon: 'pi pi-exclamation-triangle',
    acceptClass: 'p-button-danger',
    accept: () => {
      deletarItem()
    }
  })
}
</script>
```

### Com Opções

```vue
confirm.require({
  message: 'Tem certeza?',
  header: 'Confirmação',
  icon: 'pi pi-question-circle',
  acceptLabel: 'Sim',
  rejectLabel: 'Não',
  acceptClass: 'p-button-success',
  rejectClass: 'p-button-secondary',
  accept: () => {
    // Confirmar
  },
  reject: () => {
    // Cancelar
  }
})
```

### Com Template Customizado

```vue
<ConfirmationDialog>
  <template #message="slotProps">
    <div class="flex items-center gap-2">
      <i :class="slotProps.messageProps.icon"></i>
      <span>{{ slotProps.messageProps.message }}</span>
    </div>
  </template>
</ConfirmationDialog>
```

## Métodos do useConfirm

- `require(options)` - Mostra diálogo de confirmação
- `close()` - Fecha o diálogo

## Casos de Uso

- Confirmação de deleção
- Confirmação de ações críticas
- Alertas de segurança
- Validação antes de submit

## Referências

- [Documentação Oficial](https://primevue.org/confirmationdialog)
- [API Reference](https://primevue.org/api/confirmationdialog)
