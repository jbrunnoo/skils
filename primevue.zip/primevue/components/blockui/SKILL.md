# PrimeVue BlockUI Component

Componente para bloquear a UI durante operações assíncronas.

## Import

```javascript
import BlockUI from 'primevue/blockui';
```

## Uso Básico

```vue
<BlockUI :blocked="loading">
  <Panel header="Conteúdo">
    <p>Este conteúdo será bloqueado quando loading=true</p>
  </Panel>
</BlockUI>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `blocked` | boolean | Controla o estado bloqueado |
| `fullScreen` | boolean | Bloqueia o documento inteiro |
| `baseZIndex` | number | Z-index base para camadas |
| `autoZIndex` | boolean | Gerencia z-index automaticamente |

## Exemplos

### Bloquear Componente Específico

```vue
<template>
  <div>
    <Button label="Bloquear" @click="blocked = true" />
    <Button label="Desbloquear" @click="blocked = false" />
    
    <BlockUI :blocked="blocked">
      <Panel header="Painel Bloqueável">
        <p>Conteúdo que será bloqueado</p>
      </Panel>
    </BlockUI>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const blocked = ref(false)
</script>
```

### Bloquear Documento Inteiro

```vue
<template>
  <BlockUI :blocked="loading" fullScreen />
  <Button label="Carregar" @click="carregarDados" />
</template>

<script setup>
import { ref } from 'vue'
const loading = ref(false)

const carregarDados = async () => {
  loading.value = true
  try {
    await fetchData()
  } finally {
    loading.value = false
  }
}
</script>
```

### Com Timeout Automático

```vue
<template>
  <BlockUI :blocked="blocked" fullScreen />
  <Button label="Processar" @click="processar" />
</template>

<script setup>
const blocked = ref(false)

const processar = () => {
  blocked.value = true
  setTimeout(() => {
    blocked.value = false
  }, 3000) // Desbloqueia após 3 segundos
}
</script>
```

### Com Template Customizado

```vue
<BlockUI :blocked="loading">
  <template #mask>
    <div class="flex items-center justify-center">
      <ProgressSpinner />
      <span class="ml-2">Carregando...</span>
    </div>
  </template>
  <Panel>Conteúdo</Panel>
</BlockUI>
```

## Acessibilidade

- Gerencia `aria-busy` automaticamente
- Suporta `role` e `aria-live` para regiões ao vivo
- Compatível com leitores de tela

## Casos de Uso

- Bloquear formulário durante submit
- Bloquear tabela durante carregamento de dados
- Bloquear página inteira durante operações críticas
- Mostrar loading durante requisições assíncronas

## Referências

- [Documentação Oficial](https://primevue.org/blockui)
- [API Reference](https://primevue.org/api/blockui)
