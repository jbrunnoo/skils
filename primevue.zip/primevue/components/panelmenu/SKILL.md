# PrimeVue PanelMenu Component

Menu em painel com expansão de itens.

## Import

```javascript
import PanelMenu from 'primevue/panelmenu';
```

## Uso Básico

```vue
<PanelMenu :model="items" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do menu |
| `multiple` | boolean | Permite múltiplos expandidos |

## Exemplos

### Básico

```vue
<template>
  <PanelMenu :model="items" />
</template>

<script setup>
const items = ref([
  {
    label: 'Arquivo',
    icon: 'pi pi-file',
    items: [
      {
        label: 'Novo',
        icon: 'pi pi-plus',
        command: () => novo()
      },
      {
        label: 'Abrir',
        icon: 'pi pi-folder-open'
      }
    ]
  },
  {
    label: 'Editar',
    icon: 'pi pi-pencil',
    items: [
      { label: 'Copiar' },
      { label: 'Colar' }
    ]
  }
])
</script>
```

### Múltiplos Expandidos

```vue
<PanelMenu :model="items" :multiple="true" />
```

### Com Router

```vue
const items = ref([
  {
    label: 'Home',
    icon: 'pi pi-home',
    to: '/'
  },
  {
    label: 'Produtos',
    icon: 'pi pi-box',
    items: [
      { label: 'Lista', to: '/produtos' },
      { label: 'Novo', to: '/produtos/novo' }
    ]
  }
])
</PanelMenu>
```

## Estrutura de Item

```typescript
interface PanelMenuItem {
  label: string
  icon?: string
  items?: PanelMenuItem[]
  command?: () => void
  to?: string
}
```

## Casos de Uso

- Menu lateral
- Navegação hierárquica
- Menu de configurações
- Sidebar navigation

## Referências

- [Documentação Oficial](https://primevue.org/panelmenu)
- [API Reference](https://primevue.org/api/panelmenu)
