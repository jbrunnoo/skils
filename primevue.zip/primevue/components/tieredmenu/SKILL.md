# PrimeVue TieredMenu Component

Menu hierárquico em camadas (múltiplos níveis).

## Import

```javascript
import TieredMenu from 'primevue/tieredmenu';
```

## Uso Básico

```vue
<TieredMenu :model="items" popup />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do menu |
| `popup` | boolean | Menu popup (overlay) |
| `baseZIndex` | number | Z-index base |

## Exemplos

### Básico

```vue
<template>
  <TieredMenu ref="menu" :model="items" popup />
  <Button label="Menu" @click="menu.toggle($event)" />
</template>

<script setup>
const menu = ref()
const items = ref([
  {
    label: 'Arquivo',
    icon: 'pi pi-file',
    items: [
      {
        label: 'Novo',
        items: [
          { label: 'Documento' },
          { label: 'Pasta' }
        ]
      },
      { label: 'Abrir' }
    ]
  }
])
</script>
```

### Horizontal

```vue
<TieredMenu :model="items" />
```

### Com Router

```vue
const items = ref([
  {
    label: 'Home',
    to: '/'
  },
  {
    label: 'Produtos',
    items: [
      { label: 'Lista', to: '/produtos' },
      { label: 'Novo', to: '/produtos/novo' }
    ]
  }
])
```

## Estrutura de Item

```typescript
interface TieredMenuItem {
  label: string
  icon?: string
  items?: TieredMenuItem[]
  command?: () => void
  to?: string
}
```

## Casos de Uso

- Menus complexos
- Navegação hierárquica
- Menus de aplicação
- Estruturas profundas

## Referências

- [Documentação Oficial](https://primevue.org/tieredmenu)
- [API Reference](https://primevue.org/api/tieredmenu)
