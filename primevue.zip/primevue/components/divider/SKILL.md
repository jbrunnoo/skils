# PrimeVue Divider Component

Componente divisor/separador visual.

## Import

```javascript
import Divider from 'primevue/divider';
```

## Uso Básico

```vue
<Divider />
<Divider align="left">Texto</Divider>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `align` | string | Alinhamento: "left", "right", "center" |
| `layout` | string | Layout: "horizontal" ou "vertical" |
| `type` | string | Tipo: "solid", "dashed", "dotted" |

## Exemplos

### Básico

```vue
<div>
  <p>Conteúdo acima</p>
  <Divider />
  <p>Conteúdo abaixo</p>
</div>
```

### Com Texto

```vue
<Divider align="left">Ou</Divider>
<Divider align="center">Ou</Divider>
<Divider align="right">Ou</Divider>
```

### Vertical

```vue
<div class="flex">
  <span>Esquerda</span>
  <Divider layout="vertical" />
  <span>Direita</span>
</div>
```

### Com Tipo

```vue
<Divider type="solid" />
<Divider type="dashed" />
<Divider type="dotted" />
```

### Em Formulário

```vue
<form>
  <InputText v-model="nome" />
  <Divider />
  <InputText v-model="email" />
  <Divider />
  <Button label="Enviar" />
</form>
```

## Casos de Uso

- Separar seções
- Dividir conteúdo
- Separadores visuais
- Organização de layout

## Referências

- [Documentação Oficial](https://primevue.org/divider)
- [API Reference](https://primevue.org/api/divider)
