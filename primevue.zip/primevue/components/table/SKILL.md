# PrimeVue Table Component

Tabela básica do PrimeVue. Para recursos avançados (filtros, paginação, ordenação), use `DataTable`.

## Import

```javascript
import Table from 'primevue/table';
import Column from 'primevue/column';
```

## Uso Básico

```vue
<Table :value="data">
  <Column field="name" header="Nome" />
  <Column field="age" header="Idade" />
</Table>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Dados da tabela |
| `stripedRows` | boolean | Linhas alternadas |
| `hoverableRows` | boolean | Hover nas linhas |
| `size` | string | Tamanho: "small", "large" |

## Exemplos

### Básico

```vue
<template>
  <Table :value="produtos">
    <Column field="nome" header="Nome" />
    <Column field="preco" header="Preço" />
    <Column field="estoque" header="Estoque" />
  </Table>
</template>

<script setup>
const produtos = ref([
  { nome: 'Produto 1', preco: 100, estoque: 10 },
  { nome: 'Produto 2', preco: 200, estoque: 5 }
])
</script>
```

### Com Linhas Alternadas

```vue
<Table :value="dados" stripedRows>
  <Column field="nome" header="Nome" />
</Table>
```

### Com Hover

```vue
<Table :value="dados" hoverableRows>
  <Column field="nome" header="Nome" />
</Table>
```

### Com Template Customizado

```vue
<Table :value="produtos">
  <Column field="nome" header="Nome" />
  <Column field="preco" header="Preço">
    <template #body="slotProps">
      R$ {{ slotProps.data.preco }}
    </template>
  </Column>
</Table>
```

## Diferença do DataTable

- **Table**: Básica, sem filtros, paginação ou ordenação
- **DataTable**: Completa, com todos os recursos avançados

**Recomendação**: Use `DataTable` para a maioria dos casos.

## Referências

- [Documentação Oficial](https://primevue.org/table)
- [API Reference](https://primevue.org/api/table)
