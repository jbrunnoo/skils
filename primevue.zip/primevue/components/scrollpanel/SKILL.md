# PrimeVue ScrollPanel Component

Painel com scroll customizado e estilizado.

## Import

```javascript
import ScrollPanel from 'primevue/scrollpanel';
```

## Uso Básico

```vue
<ScrollPanel style="height: 200px">
  <p>Conteúdo longo aqui...</p>
</ScrollPanel>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `style` | string | Estilo inline (altura recomendada) |

## Exemplos

### Básico

```vue
<template>
  <ScrollPanel style="height: 300px; width: 100%">
    <div v-for="i in 50" :key="i" class="p-2">
      Item {{ i }}
    </div>
  </ScrollPanel>
</template>
```

### Com Conteúdo Longo

```vue
<ScrollPanel style="height: 400px">
  <div class="p-4">
    <h2>Título</h2>
    <p v-for="i in 20" :key="i">
      Parágrafo {{ i }} com muito conteúdo...
    </p>
  </div>
</ScrollPanel>
```

### Horizontal

```vue
<ScrollPanel style="width: 500px; height: 200px">
  <div class="flex" style="width: 1000px">
    <div v-for="i in 10" :key="i" class="p-4 border">
      Item {{ i }}
    </div>
  </div>
</ScrollPanel>
```

### Com Template Customizado

```vue
<ScrollPanel style="height: 300px">
  <template #content>
    <div class="custom-content">
      Conteúdo customizado
    </div>
  </template>
</ScrollPanel>
```

## Casos de Uso

- Áreas de texto longas
- Listas com scroll customizado
- Painéis laterais
- Conteúdo com altura fixa

## Referências

- [Documentação Oficial](https://primevue.org/scrollpanel)
- [API Reference](https://primevue.org/api/scrollpanel)
