# PrimeVue OtpInput Component

Input OTP (One-Time Password) para códigos de verificação.

## Import

```javascript
import OtpInput from 'primevue/otpinput';
```

## Uso Básico

```vue
<OtpInput v-model="otp" :length="6" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | string | Código OTP (v-model) |
| `length` | number | Número de dígitos |
| `disabled` | boolean | Desabilita |
| `readonly` | boolean | Somente leitura |
| `mask` | boolean | Mascara os valores |

## Exemplos

### Básico

```vue
<template>
  <OtpInput v-model="codigo" :length="6" />
  <p v-if="codigo.length === 6">Código: {{ codigo }}</p>
</template>

<script setup>
const codigo = ref('')
</script>
```

### Com 4 Dígitos

```vue
<OtpInput v-model="codigo" :length="4" />
```

### Com Máscara

```vue
<OtpInput v-model="codigo" :length="6" :mask="true" />
```

### Com Label

```vue
<div class="flex flex-column gap-2">
  <label>Digite o código de verificação</label>
  <OtpInput v-model="codigo" :length="6" />
</div>
```

### Em Formulário

```vue
<template>
  <form @submit.prevent="verificar">
    <div class="field">
      <label>Código OTP</label>
      <OtpInput v-model="codigo" :length="6" />
    </div>
    <Button type="submit" label="Verificar" />
  </form>
</template>
```

## Casos de Uso

- Verificação de email
- Autenticação de dois fatores
- Códigos de confirmação
- Validação de segurança

## Referências

- [Documentação Oficial](https://primevue.org/otpinput)
- [API Reference](https://primevue.org/api/otpinput)
