# PrimeVue ColorPicker Component

Componente seletor de cores com suporte a diferentes formatos.

## Import

```javascript
import ColorPicker from 'primevue/colorpicker';
```

## Uso Básico

```vue
<ColorPicker v-model="color" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | string | Cor selecionada (v-model) - formato hex |
| `defaultColor` | string | Cor padrão |
| `inline` | boolean | Modo inline (sem popup) |
| `format` | string | Formato: "hex", "rgb", "hsb" |
| `disabled` | boolean | Desabilita |

## Exemplos

### Básico

```vue
<template>
  <ColorPicker v-model="cor" />
  <p>Cor selecionada: {{ cor }}</p>
</template>

<script setup>
import { ref } from 'vue'
const cor = ref('#FF5733')
</script>
```

### Modo Inline

```vue
<ColorPicker v-model="cor" inline />
```

### Com Formato RGB

```vue
<ColorPicker v-model="cor" format="rgb" />
```

### Com Cor Padrão

```vue
<ColorPicker v-model="cor" defaultColor="#FF5733" />
```

### Com Label

```vue
<div class="flex flex-column gap-2">
  <label for="cor">Escolha uma cor</label>
  <ColorPicker id="cor" v-model="cor" />
</div>
```

### Integrado com Input

```vue
<template>
  <div class="flex gap-2">
    <InputText v-model="cor" placeholder="#000000" />
    <ColorPicker v-model="cor" />
  </div>
</template>
```

## Formatos Suportados

- **hex** - Hexadecimal (ex: #FF5733)
- **rgb** - RGB (ex: rgb(255, 87, 51))
- **hsb** - HSB (ex: hsb(9, 80%, 100%))

## Eventos

```vue
<ColorPicker 
  v-model="cor" 
  @change="onColorChange"
/>
```

## Casos de Uso

- Seleção de cor de tema
- Personalização de cores em formulários
- Editores de design
- Configurações de aparência

## Referências

- [Documentação Oficial](https://primevue.org/colorpicker)
- [API Reference](https://primevue.org/api/colorpicker)
