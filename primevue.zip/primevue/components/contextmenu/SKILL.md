# PrimeVue ContextMenu Component

Menu de contexto (clique direito) para ações rápidas.

## Import

```javascript
import ContextMenu from 'primevue/contextmenu';
```

## Uso Básico

```vue
<ContextMenu ref="cm" :model="items" />
<div @contextmenu="show">Clique direito aqui</div>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do menu |
| `appendTo` | string | Onde anexar (default: "body") |
| `baseZIndex` | number | Z-index base |

## Exemplos

### Básico

```vue
<template>
  <ContextMenu ref="cm" :model="menuItems" />
  <div 
    @contextmenu="onContextMenu" 
    class="p-4 border"
  >
    Clique direito aqui
  </div>
</template>

<script setup>
import { ref } from 'vue'
const cm = ref()
const menuItems = ref([
  {
    label: 'Editar',
    icon: 'pi pi-pencil',
    command: () => editar()
  },
  {
    label: 'Deletar',
    icon: 'pi pi-trash',
    command: () => deletar()
  }
])

const onContextMenu = (event) => {
  cm.value.show(event)
}
</script>
```

### Em DataTable

```vue
<template>
  <ContextMenu ref="cm" :model="menuItems" />
  <DataTable 
    :value="produtos" 
    contextMenu
    @row-contextmenu="onRowContextMenu"
  >
    <Column field="nome" header="Nome" />
  </DataTable>
</template>

<script setup>
const onRowContextMenu = (event) => {
  cm.value.show(event.originalEvent)
  // event.data contém os dados da linha
}
</script>
```

### Com Submenu

```vue
const menuItems = ref([
  {
    label: 'Ações',
    items: [
      {
        label: 'Editar',
        icon: 'pi pi-pencil',
        command: () => editar()
      },
      {
        label: 'Mais',
        items: [
          { label: 'Copiar', icon: 'pi pi-copy' },
          { label: 'Colar', icon: 'pi pi-paste' }
        ]
      }
    ]
  }
])
```

### Com Separador

```vue
const menuItems = ref([
  { label: 'Editar' },
  { separator: true },
  { label: 'Deletar' }
])
```

## Estrutura de Item

```typescript
interface MenuItem {
  label: string
  icon?: string
  command?: () => void
  items?: MenuItem[]
  separator?: boolean
  disabled?: boolean
}
```

## Casos de Uso

- Ações rápidas em tabelas
- Menu de contexto em listas
- Atalhos de ações
- Operações em linhas

## Referências

- [Documentação Oficial](https://primevue.org/contextmenu)
- [API Reference](https://primevue.org/api/contextmenu)
