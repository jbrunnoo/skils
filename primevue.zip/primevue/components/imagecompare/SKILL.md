# PrimeVue ImageCompare Component

Componente para comparar duas imagens lado a lado com slider.

## Import

```javascript
import ImageCompare from 'primevue/imagecompare';
```

## Uso Básico

```vue
<ImageCompare :before="beforeImage" :after="afterImage" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `before` | string | URL da imagem "antes" |
| `after` | string | URL da imagem "depois" |
| `orientation` | string | "horizontal" ou "vertical" |

## Exemplos

### Básico

```vue
<template>
  <ImageCompare 
    :before="antes" 
    :after="depois" 
  />
</template>

<script setup>
const antes = ref('/imagens/antes.jpg')
const depois = ref('/imagens/depois.jpg')
</script>
```

### Vertical

```vue
<ImageCompare 
  :before="antes" 
  :after="depois"
  orientation="vertical"
/>
```

### Com Alt Text

```vue
<ImageCompare 
  :before="antes" 
  :after="depois"
  beforeAlt="Antes"
  afterAlt="Depois"
/>
```

## Casos de Uso

- Comparação de imagens
- Antes/depois
- Transformações visuais
- Demonstrações de mudanças

## Referências

- [Documentação Oficial](https://primevue.org/imagecompare)
- [API Reference](https://primevue.org/api/imagecompare)
