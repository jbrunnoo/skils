# PrimeVue ToggleSwitch Component

Componente de toggle switch do PrimeVue. **BREAKING CHANGE v4**: `InputSwitch` foi renomeado para `ToggleSwitch`.

## Import

```javascript
import ToggleSwitch from 'primevue/toggleswitch';
```

## Uso Básico

```vue
<ToggleSwitch v-model="checked" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | boolean | Estado (v-model) |
| `disabled` | boolean | Desabilita |
| `invalid` | boolean | Estado inválido |

## Exemplos

### Básico

```vue
<ToggleSwitch v-model="ativo" />
```

### Com Label

```vue
<div class="flex items-center gap-2">
  <ToggleSwitch v-model="notificacoes" inputId="notif" />
  <label for="notif">Receber notificações</label>
</div>
```

## Migração de InputSwitch (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<InputSwitch v-model="checked" />

<!-- v4 (CORRETO) -->
<ToggleSwitch v-model="checked" />
```

## Referências

- [Documentação Oficial](https://primevue.org/toggleswitch)
- [API Reference](https://primevue.org/api/toggleswitch)
