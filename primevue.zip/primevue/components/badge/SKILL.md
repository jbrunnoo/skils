# PrimeVue Badge Component

Componente de badge do PrimeVue. **BREAKING CHANGE v4**: Diretiva `Badge` foi substituída por componente `OverlayBadge`.

## Import

```javascript
import Badge from 'primevue/badge';
import OverlayBadge from 'primevue/overlaybadge';
```

## Uso Básico

```vue
<Badge value="5" />
<OverlayBadge value="2">
  <Button icon="pi pi-bell" />
</OverlayBadge>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | string/number | Valor do badge |
| `severity` | string | "success", "info", "warn", "danger" |

## Exemplos

### Básico

```vue
<Badge value="5" />
```

### Com Severidade

```vue
<Badge value="3" severity="danger" />
```

### Overlay Badge

```vue
<OverlayBadge value="2">
  <Button icon="pi pi-bell" />
</OverlayBadge>
```

## Referências

- [Documentação Oficial](https://primevue.org/badge)
- [API Reference](https://primevue.org/api/badge)
