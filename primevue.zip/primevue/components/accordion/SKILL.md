# PrimeVue Accordion Component

Componente de accordion do PrimeVue. **BREAKING CHANGE v4**: Reimplementado com nova estrutura.

## Import

```javascript
import Accordion from 'primevue/accordion';
import AccordionPanel from 'primevue/accordionpanel';
import AccordionHeader from 'primevue/accordionheader';
import AccordionContent from 'primevue/accordioncontent';
```

## Uso Básico

```vue
<Accordion v-model:value="painelAtivo">
  <AccordionPanel value="1">
    <AccordionHeader>Painel 1</AccordionHeader>
    <AccordionContent>Conteúdo 1</AccordionContent>
  </AccordionPanel>
  <AccordionPanel value="2">
    <AccordionHeader>Painel 2</AccordionHeader>
    <AccordionContent>Conteúdo 2</AccordionContent>
  </AccordionPanel>
</Accordion>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | any | Painel ativo (v-model:value) |
| `multiple` | boolean | Permite múltiplos abertos |

## Exemplos

### Básico

```vue
<template>
  <Accordion v-model:value="ativo">
    <AccordionPanel value="1">
      <AccordionHeader>Pergunta 1</AccordionHeader>
      <AccordionContent>Resposta 1</AccordionContent>
    </AccordionPanel>
    <AccordionPanel value="2">
      <AccordionHeader>Pergunta 2</AccordionHeader>
      <AccordionContent>Resposta 2</AccordionContent>
    </AccordionPanel>
  </Accordion>
</template>

<script setup>
const ativo = ref('1')
</script>
```

### Múltiplos Abertos

```vue
<Accordion v-model:value="ativos" :multiple="true">
  <AccordionPanel value="1">
    <AccordionHeader>Painel 1</AccordionHeader>
    <AccordionContent>Conteúdo 1</AccordionContent>
  </AccordionPanel>
  <AccordionPanel value="2">
    <AccordionHeader>Painel 2</AccordionHeader>
    <AccordionContent>Conteúdo 2</AccordionContent>
  </AccordionPanel>
</Accordion>

<script setup>
const ativos = ref(['1', '2']) // Array quando multiple=true
</script>
```

## Referências

- [Documentação Oficial](https://primevue.org/accordion)
- [API Reference](https://primevue.org/api/accordion)
