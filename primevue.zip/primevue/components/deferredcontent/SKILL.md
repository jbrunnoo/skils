# PrimeVue DeferredContent Component

Componente para carregar conteúdo quando visível (lazy loading).

## Import

```javascript
import DeferredContent from 'primevue/deferredcontent';
```

## Uso Básico

```vue
<DeferredContent>
  <div>Conteúdo carregado quando visível</div>
</DeferredContent>
```

## Exemplos

### Básico

```vue
<template>
  <div>
    <p>Conteúdo inicial</p>
    
    <DeferredContent>
      <div class="p-4 border">
        <h3>Conteúdo Carregado</h3>
        <p>Este conteúdo só será carregado quando visível na tela.</p>
      </div>
    </DeferredContent>
  </div>
</template>
```

### Com Imagens

```vue
<DeferredContent>
  <img src="/imagem-grande.jpg" alt="Imagem" />
</DeferredContent>
```

### Com Componentes Pesados

```vue
<DeferredContent>
  <Chart type="bar" :data="chartData" />
</DeferredContent>
```

### Com Múltiplos Elementos

```vue
<DeferredContent>
  <div>
    <h2>Título</h2>
    <p>Parágrafo</p>
    <DataTable :value="dados" />
  </div>
</DeferredContent>
```

## Eventos

```vue
<DeferredContent @load="onContentLoad">
  <div>Conteúdo</div>
</DeferredContent>

<script setup>
const onContentLoad = () => {
  console.log('Conteúdo carregado')
}
</script>
```

## Casos de Uso

- Lazy loading de imagens
- Carregamento sob demanda
- Performance em listas longas
- Otimização de inicialização

## Referências

- [Documentação Oficial](https://primevue.org/deferredcontent)
- [API Reference](https://primevue.org/api/deferredcontent)
