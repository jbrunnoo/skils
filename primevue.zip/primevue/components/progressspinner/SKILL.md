# PrimeVue ProgressSpinner Component

Componente de spinner de progresso do PrimeVue.

## Import

```javascript
import ProgressSpinner from 'primevue/progressspinner';
```

## Uso Básico

```vue
<ProgressSpinner />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `strokeWidth` | string | Largura do traço |
| `fill` | string | Cor de preenchimento |
| `animationDuration` | string | Duração da animação |

## Exemplos

### Básico

```vue
<ProgressSpinner />
```

### Customizado

```vue
<ProgressSpinner strokeWidth="4" />
```

## Referências

- [Documentação Oficial](https://primevue.org/progressspinner)
- [API Reference](https://primevue.org/api/progressspinner)
