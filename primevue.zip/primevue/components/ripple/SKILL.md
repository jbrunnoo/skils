# PrimeVue Ripple Directive

Diretiva para efeito ripple (ondas) em componentes.

## Import

```javascript
import Ripple from 'primevue/ripple';
```

## Configuração Global

```javascript
// No main.ts
app.use(PrimeVue, { ripple: true })

// Ou como diretiva
app.directive('ripple', Ripple);
```

## Uso Básico

```vue
<Button v-ripple label="Com Ripple" />
```

## Exemplos

### Em Botões

```vue
<Button v-ripple label="Clique" />
<Button v-ripple icon="pi pi-check" />
```

### Em Cards

```vue
<Card v-ripple class="cursor-pointer">
  <template #title>Título</template>
  <template #content>Conteúdo</template>
</Card>
```

### Em Divs

```vue
<div v-ripple class="p-4 border cursor-pointer">
  Clique aqui para ver o efeito
</div>
```

### Configuração Global

```javascript
// Habilita ripple em todos os componentes suportados
app.use(PrimeVue, { 
  ripple: true 
})
```

## Componentes com Ripple Nativo

Quando `ripple: true` na configuração, estes componentes têm ripple automático:
- Button
- Checkbox
- RadioButton
- ToggleSwitch
- E outros

## Casos de Uso

- Feedback visual em cliques
- Melhorar UX em elementos clicáveis
- Consistência visual
- Material Design style

## Referências

- [Documentação Oficial](https://primevue.org/ripple)
- [API Reference](https://primevue.org/api/ripple)
