# PrimeVue Tabs Component

Componente de abas do PrimeVue. **BREAKING CHANGE v4**: `TabView` foi substituído por `Tabs` com nova estrutura.

## Import

```javascript
import Tabs from 'primevue/tabs';
import TabList from 'primevue/tablist';
import Tab from 'primevue/tab';
import TabPanels from 'primevue/tabpanels';
import TabPanel from 'primevue/tabpanel';
```

## Uso Básico

```vue
<Tabs v-model:value="activeTab">
  <TabList>
    <Tab value="1">Aba 1</Tab>
    <Tab value="2">Aba 2</Tab>
  </TabList>
  <TabPanels>
    <TabPanel value="1">Conteúdo 1</TabPanel>
    <TabPanel value="2">Conteúdo 2</TabPanel>
  </TabPanels>
</Tabs>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | any | Aba ativa (v-model:value) |
| `orientation` | string | "horizontal" ou "vertical" |

## Exemplos

### Básico

```vue
<template>
  <Tabs v-model:value="abaAtiva">
    <TabList>
      <Tab value="home">Home</Tab>
      <Tab value="about">Sobre</Tab>
      <Tab value="contact">Contato</Tab>
    </TabList>
    <TabPanels>
      <TabPanel value="home">Conteúdo Home</TabPanel>
      <TabPanel value="about">Conteúdo Sobre</TabPanel>
      <TabPanel value="contact">Conteúdo Contato</TabPanel>
    </TabPanels>
  </Tabs>
</template>

<script setup>
const abaAtiva = ref('home')
</script>
```

### Vertical

```vue
<Tabs v-model:value="abaAtiva" orientation="vertical">
  <TabList>
    <Tab value="1">Aba 1</Tab>
    <Tab value="2">Aba 2</Tab>
  </TabList>
  <TabPanels>
    <TabPanel value="1">Conteúdo 1</TabPanel>
    <TabPanel value="2">Conteúdo 2</TabPanel>
  </TabPanels>
</Tabs>
```

### Para Navegação (Sem TabPanels)

```vue
<Tabs v-model:value="rotaAtiva">
  <TabList>
    <Tab value="/home" asChild>
      <router-link to="/home">Home</router-link>
    </Tab>
    <Tab value="/about" asChild>
      <router-link to="/about">Sobre</router-link>
    </Tab>
  </TabList>
</Tabs>
```

## Migração de TabView (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<TabView>
  <TabPanel header="Aba 1">Conteúdo 1</TabPanel>
  <TabPanel header="Aba 2">Conteúdo 2</TabPanel>
</TabView>

<!-- v4 (CORRETO) -->
<Tabs v-model:value="activeTab">
  <TabList>
    <Tab value="1">Aba 1</Tab>
    <Tab value="2">Aba 2</Tab>
  </TabList>
  <TabPanels>
    <TabPanel value="1">Conteúdo 1</TabPanel>
    <TabPanel value="2">Conteúdo 2</TabPanel>
  </TabPanels>
</Tabs>
```

## Referências

- [Documentação Oficial](https://primevue.org/tabs)
- [API Reference](https://primevue.org/api/tabs)
