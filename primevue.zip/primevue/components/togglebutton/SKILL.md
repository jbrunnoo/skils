# PrimeVue ToggleButton Component

Botão toggle.

## Import

```javascript
import ToggleButton from 'primevue/togglebutton';
```

## Uso Básico

```vue
<ToggleButton v-model="checked" onLabel="Sim" offLabel="Não" />
```

## Referências

- [Documentação Oficial](https://primevue.org/togglebutton)
- [API Reference](https://primevue.org/api/togglebutton)
