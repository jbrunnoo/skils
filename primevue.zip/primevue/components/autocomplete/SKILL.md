# PrimeVue AutoComplete Component

Componente de autocomplete do PrimeVue com suporte a busca e sugestões.

## Import

```javascript
import AutoComplete from 'primevue/autocomplete';
```

## Uso Básico

```vue
<AutoComplete v-model="selected" :suggestions="suggestions" @complete="search" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `suggestions` | array | Lista de sugestões |
| `completeMethod` | function | Método para buscar sugestões |
| `optionLabel` | string | Propriedade para label |
| `optionValue` | string | Propriedade para value |
| `multiple` | boolean | Seleção múltipla |
| `dropdown` | boolean | Mostra dropdown |
| `forceSelection` | boolean | Força seleção da lista |

## Exemplos

### Básico

```vue
<template>
  <AutoComplete 
    v-model="selected" 
    :suggestions="suggestions" 
    @complete="search"
    optionLabel="name"
  />
</template>

<script setup>
import { ref } from 'vue'
const selected = ref(null)
const suggestions = ref([])

const search = (event) => {
  // Buscar sugestões baseado em event.query
  suggestions.value = items.filter(item => 
    item.name.toLowerCase().includes(event.query.toLowerCase())
  )
}
</script>
```

### Com Dropdown

```vue
<AutoComplete 
  v-model="selected" 
  :suggestions="suggestions"
  dropdown
  optionLabel="name"
/>
```

## Referências

- [Documentação Oficial](https://primevue.org/autocomplete)
- [API Reference](https://primevue.org/api/autocomplete)
