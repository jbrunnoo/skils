# PrimeVue Drawer Component

Componente de drawer (gaveta lateral) do PrimeVue. **BREAKING CHANGE v4**: `Sidebar` foi renomeado para `Drawer`.

## Import

```javascript
import Drawer from 'primevue/drawer';
```

## Uso Básico

```vue
<Drawer v-model:visible="show" position="left">
  <p>Conteúdo do drawer</p>
</Drawer>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `visible` | boolean | Visibilidade (v-model:visible) |
| `position` | string | Posição: "left", "right", "top", "bottom" |
| `modal` | boolean | Modal (bloqueia interação) |
| `dismissable` | boolean | Fecha ao clicar fora |
| `showCloseIcon` | boolean | Mostra ícone fechar |

## Exemplos

### Básico

```vue
<template>
  <Button label="Abrir" @click="show = true" />
  <Drawer v-model:visible="show" position="left">
    <h3>Menu Lateral</h3>
    <p>Conteúdo aqui</p>
  </Drawer>
</template>

<script setup>
const show = ref(false)
</script>
```

### Posições

```vue
<Drawer v-model:visible="show" position="left">Esquerda</Drawer>
<Drawer v-model:visible="show" position="right">Direita</Drawer>
<Drawer v-model:visible="show" position="top">Topo</Drawer>
<Drawer v-model:visible="show" position="bottom">Baixo</Drawer>
```

### Modal

```vue
<Drawer 
  v-model:visible="show" 
  position="right"
  :modal="true"
  :dismissable="true"
>
  <p>Drawer modal</p>
</Drawer>
```

## Migração de Sidebar (v3 → v4)

```vue
<!-- v3 (DEPRECATED) -->
<Sidebar v-model:visible="show" />

<!-- v4 (CORRETO) -->
<Drawer v-model:visible="show" position="left" />
```

## Referências

- [Documentação Oficial](https://primevue.org/drawer)
- [API Reference](https://primevue.org/api/drawer)
