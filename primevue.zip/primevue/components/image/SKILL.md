# PrimeVue Image Component

Componente de imagem com preview e zoom.

## Import

```javascript
import Image from 'primevue/image';
```

## Uso Básico

```vue
<Image src="path/to/image.jpg" alt="Descrição" width="250" preview />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `src` | string | URL da imagem |
| `alt` | string | Texto alternativo |
| `width` | string | Largura |
| `height` | string | Altura |
| `preview` | boolean | Habilita preview |
| `zoom` | boolean | Habilita zoom |
| `download` | boolean | Permite download |
| `indicatorIcon` | string | Ícone do indicador |

## Exemplos

### Básico

```vue
<Image src="/imagem.jpg" alt="Minha imagem" width="300" />
```

### Com Preview

```vue
<Image 
  src="/imagem.jpg" 
  alt="Clique para ampliar" 
  width="250" 
  preview 
/>
```

### Com Zoom

```vue
<Image 
  src="/imagem.jpg" 
  alt="Imagem" 
  width="300" 
  preview 
  zoom 
/>
```

### Com Download

```vue
<Image 
  src="/imagem.jpg" 
  alt="Imagem" 
  width="300" 
  preview 
  download 
/>
```

### Responsivo

```vue
<Image 
  src="/imagem.jpg" 
  alt="Imagem" 
  width="100%" 
  class="w-full"
/>
```

### Com Template

```vue
<Image src="/imagem.jpg" alt="Imagem" width="300" preview>
  <template #indicator>
    <i class="pi pi-search"></i>
  </template>
</Image>
```

## Casos de Uso

- Galeria de produtos
- Visualização de imagens
- Preview de uploads
- Zoom em detalhes

## Referências

- [Documentação Oficial](https://primevue.org/image)
- [API Reference](https://primevue.org/api/image)
