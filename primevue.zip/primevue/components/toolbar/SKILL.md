# PrimeVue Toolbar Component

Barra de ferramentas com slots para início e fim.

## Import

```javascript
import Toolbar from 'primevue/toolbar';
```

## Uso Básico

```vue
<Toolbar>
  <template #start>
    <Button label="Novo" />
  </template>
  <template #end>
    <Button icon="pi pi-search" />
  </template>
</Toolbar>
```

## Slots

| Slot | Descrição |
|------|-----------|
| `start` | Conteúdo à esquerda |
| `end` | Conteúdo à direita |
| `center` | Conteúdo central (opcional) |

## Exemplos

### Básico

```vue
<Toolbar>
  <template #start>
    <Button label="Novo" icon="pi pi-plus" />
    <Button label="Editar" icon="pi pi-pencil" />
  </template>
  <template #end>
    <Button icon="pi pi-search" />
    <Button icon="pi pi-cog" />
  </template>
</Toolbar>
```

### Com Centro

```vue
<Toolbar>
  <template #start>
    <Button label="Voltar" />
  </template>
  <template #center>
    <h3>Título</h3>
  </template>
  <template #end>
    <Button label="Salvar" />
  </template>
</Toolbar>
```

### Com Input de Busca

```vue
<Toolbar>
  <template #start>
    <Button label="Novo" />
  </template>
  <template #end>
    <IconField>
      <InputIcon class="pi pi-search" />
      <InputText v-model="busca" placeholder="Buscar..." />
    </IconField>
  </template>
</Toolbar>
```

### Com Menu

```vue
<Toolbar>
  <template #start>
    <Button label="Ações" />
  </template>
  <template #end>
    <Menu :model="menuItems" popup>
      <template #item="{ item }">
        <Button :label="item.label" :icon="item.icon" text />
      </template>
    </Menu>
  </template>
</Toolbar>
```

## Casos de Uso

- Barra de ações em listas
- Toolbar de editor
- Navegação de página
- Ações globais

## Referências

- [Documentação Oficial](https://primevue.org/toolbar)
- [API Reference](https://primevue.org/api/toolbar)
