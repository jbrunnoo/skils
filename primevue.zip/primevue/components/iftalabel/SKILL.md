# PrimeVue IftaLabel Component

Label in-field moderno (top-aligned).

## Import

```javascript
import IftaLabel from 'primevue/iftalabel';
```

## Uso Básico

```vue
<IftaLabel for="username">Usuário</IftaLabel>
<InputText id="username" v-model="username" />
```

## Referências

- [Documentação Oficial](https://primevue.org/iftalabel)
- [API Reference](https://primevue.org/api/iftalabel)
