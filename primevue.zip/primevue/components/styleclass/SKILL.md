# PrimeVue StyleClass Directive

Diretiva para animar classes CSS com transições.

## Import

```javascript
import StyleClass from 'primevue/styleclass';
```

## Configuração

```javascript
app.directive('styleclass', StyleClass);
```

## Uso Básico

```vue
<Button 
  v-styleclass="{ 
    selector: '@next', 
    enterClass: 'hidden', 
    enterActiveClass: 'fadein' 
  }" 
  label="Toggle" 
/>
<div class="hidden">Conteúdo</div>
```

## Exemplos

### Toggle Simples

```vue
<template>
  <Button 
    v-styleclass="{ 
      selector: '@next', 
      enterClass: 'hidden', 
      enterActiveClass: 'fadein',
      leaveActiveClass: 'fadeout'
    }" 
    label="Mostrar/Ocultar" 
  />
  <div class="hidden">Conteúdo que aparece/desaparece</div>
</template>
```

### Com Seletor

```vue
<Button 
  v-styleclass="{ 
    selector: '.meu-elemento',
    enterClass: 'opacity-0',
    enterActiveClass: 'transition-opacity'
  }" 
  label="Animar" 
/>
<div class="meu-elemento">Elemento</div>
```

## Opções

```typescript
interface StyleClassOptions {
  selector: string
  enterClass: string
  enterActiveClass: string
  leaveClass?: string
  leaveActiveClass?: string
  hideOnOutsideClick?: boolean
  toggleClass?: string
}
```

## Casos de Uso

- Animações de entrada/saída
- Toggle de classes
- Transições CSS
- Efeitos visuais

## Referências

- [Documentação Oficial](https://primevue.org/styleclass)
- [API Reference](https://primevue.org/api/styleclass)
