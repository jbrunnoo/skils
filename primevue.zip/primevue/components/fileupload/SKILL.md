# PrimeVue FileUpload Component

Componente de upload de arquivos com drag & drop e preview.

## Import

```javascript
import FileUpload from 'primevue/fileupload';
```

## Uso Básico

```vue
<FileUpload mode="basic" name="file" url="/api/upload" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `mode` | string | "basic" ou "advanced" |
| `name` | string | Nome do campo |
| `url` | string | URL do endpoint |
| `multiple` | boolean | Upload múltiplo |
| `accept` | string | Tipos aceitos (ex: "image/*") |
| `maxFileSize` | number | Tamanho máximo (bytes) |
| `auto` | boolean | Upload automático |
| `chooseLabel` | string | Label do botão |

## Exemplos

### Modo Básico

```vue
<template>
  <FileUpload 
    mode="basic" 
    name="arquivo" 
    url="/api/upload"
    accept="image/*"
    :maxFileSize="1000000"
    @upload="onUpload"
  />
</template>

<script setup>
const onUpload = (event) => {
  console.log('Upload completo:', event)
}
</script>
```

### Modo Avançado (Drag & Drop)

```vue
<FileUpload 
  mode="advanced" 
  name="arquivos" 
  url="/api/upload"
  :multiple="true"
  accept="image/*"
  :maxFileSize="5000000"
  @upload="onUpload"
  @error="onError"
/>
```

### Com Preview

```vue
<FileUpload 
  mode="advanced"
  name="imagem"
  url="/api/upload"
  accept="image/*"
  :previewWidth="200"
  @select="onSelect"
/>

<script setup>
const onSelect = (event) => {
  // event.files contém os arquivos selecionados
  console.log('Arquivos:', event.files)
}
</script>
```

### Upload Manual

```vue
<FileUpload 
  mode="advanced"
  name="arquivo"
  :auto="false"
  @select="onSelect"
/>

<script setup>
const fileUpload = ref()

const onSelect = (event) => {
  // Upload manual
  fileUpload.value.upload()
}
</script>
```

### Com Validação

```vue
<FileUpload 
  mode="advanced"
  name="arquivo"
  accept=".pdf,.doc,.docx"
  :maxFileSize="10000000"
  :invalidFileSizeMessage="'Arquivo muito grande'"
  :invalidFileTypeMessage="'Tipo de arquivo inválido'"
/>
```

## Eventos

- `@select` - Arquivo selecionado
- `@upload` - Upload completo
- `@error` - Erro no upload
- `@before-upload` - Antes do upload
- `@progress` - Progresso do upload

## Casos de Uso

- Upload de imagens
- Upload de documentos
- Envio de arquivos
- Galeria de uploads

## Referências

- [Documentação Oficial](https://primevue.org/fileupload)
- [API Reference](https://primevue.org/api/fileupload)
