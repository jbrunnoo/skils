# PrimeVue Skeleton Component

Componente de skeleton/placeholder do PrimeVue para loading states.

## Import

```javascript
import Skeleton from 'primevue/skeleton';
```

## Uso Básico

```vue
<Skeleton />
<Skeleton width="100%" height="2rem" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `width` | string | Largura |
| `height` | string | Altura |
| `shape` | string | "rectangle", "circle" |
| `size` | string | Tamanho para circle |

## Exemplos

### Básico

```vue
<Skeleton />
```

### Retângulo

```vue
<Skeleton width="100%" height="2rem" />
```

### Círculo

```vue
<Skeleton shape="circle" size="3rem" />
```

## Referências

- [Documentação Oficial](https://primevue.org/skeleton)
- [API Reference](https://primevue.org/api/skeleton)
