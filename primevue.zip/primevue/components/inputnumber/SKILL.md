# PrimeVue InputNumber Component

Componente de input numérico do PrimeVue com incremento/decremento.

## Import

```javascript
import InputNumber from 'primevue/inputnumber';
```

## Uso Básico

```vue
<InputNumber v-model="value" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | number | Valor (v-model) |
| `min` | number | Valor mínimo |
| `max` | number | Valor máximo |
| `step` | number | Incremento/decremento |
| `showButtons` | boolean | Mostra botões +/- |
| `buttonLayout` | string | "stacked", "horizontal", "vertical" |
| `prefix` | string | Prefixo (ex: "$") |
| `suffix` | string | Sufixo (ex: "kg") |
| `locale` | string | Locale para formatação |

## Exemplos

### Básico

```vue
<InputNumber v-model="quantidade" />
```

### Com Botões

```vue
<InputNumber v-model="valor" showButtons />
```

### Com Limites

```vue
<InputNumber v-model="valor" :min="0" :max="100" :step="5" />
```

### Com Prefixo/Sufixo

```vue
<InputNumber v-model="preco" prefix="R$" />
<InputNumber v-model="peso" suffix=" kg" />
```

## Referências

- [Documentação Oficial](https://primevue.org/inputnumber)
- [API Reference](https://primevue.org/api/inputnumber)
