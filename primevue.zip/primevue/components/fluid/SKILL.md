# PrimeVue Fluid Component

Wrapper para aplicar largura total em inputs.

## Import

```javascript
import Fluid from 'primevue/fluid';
```

## Uso Básico

```vue
<Fluid>
  <InputText placeholder="Largura Total" />
  <Select placeholder="Largura Total" />
</Fluid>
```

## Melhor Prática

Use Fluid ao invés de adicionar prop `fluid` em cada campo.

## Referências

- [Documentação Oficial](https://primevue.org/fluid)
- [API Reference](https://primevue.org/api/fluid)
