# PrimeVue Splitter Component

Componente divisor de painéis redimensionáveis.

## Import

```javascript
import Splitter from 'primevue/splitter';
import SplitterPanel from 'primevue/splitterpanel';
```

## Uso Básico

```vue
<Splitter>
  <SplitterPanel :size="50">Painel 1</SplitterPanel>
  <SplitterPanel :size="50">Painel 2</SplitterPanel>
</Splitter>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `layout` | string | Layout: "horizontal" ou "vertical" |
| `gutterSize` | number | Tamanho do divisor |
| `stateKey` | string | Chave para salvar estado |
| `stateStorage` | string | "session" ou "local" |

## Exemplos

### Horizontal

```vue
<template>
  <Splitter style="height: 300px">
    <SplitterPanel :size="30">
      <div class="p-3">Painel Esquerdo</div>
    </SplitterPanel>
    <SplitterPanel :size="70">
      <div class="p-3">Painel Direito</div>
    </SplitterPanel>
  </Splitter>
</template>
```

### Vertical

```vue
<Splitter layout="vertical" style="height: 400px">
  <SplitterPanel :size="40">Painel Superior</SplitterPanel>
  <SplitterPanel :size="60">Painel Inferior</SplitterPanel>
</Splitter>
```

### Múltiplos Painéis

```vue
<Splitter>
  <SplitterPanel :size="25">Painel 1</SplitterPanel>
  <SplitterPanel :size="50">Painel 2</SplitterPanel>
  <SplitterPanel :size="25">Painel 3</SplitterPanel>
</Splitter>
```

### Com Persistência de Estado

```vue
<Splitter 
  stateKey="splitter-state"
  stateStorage="local"
>
  <SplitterPanel :size="30">Painel 1</SplitterPanel>
  <SplitterPanel :size="70">Painel 2</SplitterPanel>
</Splitter>
```

### Com Min/Max Size

```vue
<Splitter>
  <SplitterPanel :size="30" :minSize="20" :maxSize="40">
    Painel com limites
  </SplitterPanel>
  <SplitterPanel :size="70">Painel 2</SplitterPanel>
</Splitter>
```

## Casos de Uso

- Layouts divididos (editor + preview)
- Painéis laterais redimensionáveis
- Divisão de conteúdo
- Interface tipo IDE

## Referências

- [Documentação Oficial](https://primevue.org/splitter)
- [API Reference](https://primevue.org/api/splitter)
