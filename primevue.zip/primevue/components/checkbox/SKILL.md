# PrimeVue Checkbox Component

Componente de checkbox do PrimeVue.

## Import

```javascript
import Checkbox from 'primevue/checkbox';
```

## Uso Básico

```vue
<Checkbox v-model="checked" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | boolean | Estado (v-model) |
| `binary` | boolean | Valor binário (true/false) |
| `value` | any | Valor quando não é binary |
| `disabled` | boolean | Desabilita |
| `invalid` | boolean | Estado inválido |
| `indeterminate` | boolean | Estado indeterminado (v4) |

## Exemplos

### Básico

```vue
<template>
  <Checkbox v-model="aceito" />
  <label>Aceito os termos</label>
</template>

<script setup>
import { ref } from 'vue'
const aceito = ref(false)
</script>
```

### Com Label

```vue
<Checkbox v-model="aceito" inputId="terms" />
<label for="terms">Aceito os termos</label>
```

### Indeterminado

```vue
<Checkbox v-model="todos" :indeterminate="indeterminado" />
```

### Array de Valores

```vue
<template>
  <Checkbox v-model="selecionados" value="opcao1" inputId="op1" />
  <label for="op1">Opção 1</label>
  
  <Checkbox v-model="selecionados" value="opcao2" inputId="op2" />
  <label for="op2">Opção 2</label>
</template>

<script setup>
const selecionados = ref([]) // ['opcao1', 'opcao2']
</script>
```

## Referências

- [Documentação Oficial](https://primevue.org/checkbox)
- [API Reference](https://primevue.org/api/checkbox)
