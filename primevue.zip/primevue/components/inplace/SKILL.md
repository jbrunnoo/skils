# PrimeVue Inplace Component

Componente para edição inline de conteúdo.

## Import

```javascript
import Inplace from 'primevue/inplace';
import InplaceDisplay from 'primevue/inplacedisplay';
import InplaceContent from 'primevue/inplacecontent';
```

## Uso Básico

```vue
<Inplace>
  <InplaceDisplay>Clique para editar</InplaceDisplay>
  <InplaceContent>
    <InputText v-model="texto" />
  </InplaceContent>
</Inplace>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `active` | boolean | Estado ativo (v-model:active) |
| `closable` | boolean | Mostra botão fechar |

## Exemplos

### Básico

```vue
<template>
  <Inplace>
    <InplaceDisplay>
      {{ texto || 'Clique para editar' }}
    </InplaceDisplay>
    <InplaceContent>
      <InputText v-model="texto" @blur="salvar" />
    </InplaceContent>
  </Inplace>
</template>

<script setup>
const texto = ref('Texto editável')
const salvar = () => {
  // Salvar alterações
}
</script>
```

### Com Botão Fechar

```vue
<Inplace :closable="true">
  <InplaceDisplay>{{ nome }}</InplaceDisplay>
  <InplaceContent>
    <InputText v-model="nome" />
    <Button label="Salvar" @click="salvar" />
  </InplaceContent>
</Inplace>
```

### Edição de Título

```vue
<Inplace>
  <InplaceDisplay>
    <h2>{{ titulo }}</h2>
  </InplaceDisplay>
  <InplaceContent>
    <InputText v-model="titulo" />
  </InplaceContent>
</Inplace>
```

## Casos de Uso

- Edição rápida de texto
- Edição inline de campos
- Títulos editáveis
- Conteúdo editável

## Referências

- [Documentação Oficial](https://primevue.org/inplace)
- [API Reference](https://primevue.org/api/inplace)
