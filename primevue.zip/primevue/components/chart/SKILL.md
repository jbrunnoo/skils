# PrimeVue Chart Component

Componente de gráficos baseado em Chart.js para visualização de dados.

## Import

```javascript
import Chart from 'primevue/chart';
```

## Instalação

```bash
npm install chart.js
```

## Uso Básico

```vue
<Chart type="bar" :data="chartData" :options="chartOptions" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `type` | string | Tipo: "line", "bar", "pie", "doughnut", "polarArea", "radar" |
| `data` | object | Dados do gráfico |
| `options` | object | Opções de configuração |
| `plugins` | array | Plugins do Chart.js |

## Exemplos

### Gráfico de Barras

```vue
<template>
  <Chart type="bar" :data="chartData" />
</template>

<script setup>
import { ref } from 'vue'

const chartData = ref({
  labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai'],
  datasets: [
    {
      label: 'Vendas',
      data: [65, 59, 80, 81, 56],
      backgroundColor: '#42A5F5'
    }
  ]
})
</script>
```

### Gráfico de Linha

```vue
<template>
  <Chart type="line" :data="chartData" :options="options" />
</template>

<script setup>
const chartData = ref({
  labels: ['Jan', 'Fev', 'Mar', 'Abr'],
  datasets: [
    {
      label: 'Receita',
      data: [50, 60, 70, 80],
      borderColor: '#42A5F5',
      tension: 0.4
    }
  ]
})

const options = ref({
  responsive: true,
  plugins: {
    legend: {
      position: 'top'
    }
  }
})
</script>
```

### Gráfico de Pizza

```vue
<template>
  <Chart type="pie" :data="chartData" />
</template>

<script setup>
const chartData = ref({
  labels: ['A', 'B', 'C'],
  datasets: [
    {
      data: [300, 50, 100],
      backgroundColor: ['#42A5F5', '#66BB6A', '#FFA726']
    }
  ]
})
</script>
```

### Gráfico de Doughnut

```vue
<Chart type="doughnut" :data="chartData" />
```

### Gráfico Radar

```vue
<Chart type="radar" :data="chartData" />
```

### Atualizar Dados

```vue
<template>
  <Chart type="bar" :data="chartData" ref="chart" />
  <Button @click="atualizar" label="Atualizar" />
</template>

<script setup>
import { ref } from 'vue'

const chart = ref()
const chartData = ref({ /* dados */ })

const atualizar = () => {
  chartData.value.datasets[0].data = [10, 20, 30, 40]
  chart.value.refresh() // Atualiza o gráfico
}
</script>
```

## Tipos de Gráficos

- **line** - Linha
- **bar** - Barras
- **pie** - Pizza
- **doughnut** - Rosca
- **polarArea** - Área polar
- **radar** - Radar

## Opções Comuns

```javascript
const options = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top'
    },
    title: {
      display: true,
      text: 'Título do Gráfico'
    }
  },
  scales: {
    y: {
      beginAtZero: true
    }
  }
}
```

## Referências

- [Documentação Oficial](https://primevue.org/chart)
- [API Reference](https://primevue.org/api/chart)
- [Chart.js Docs](https://www.chartjs.org/)
