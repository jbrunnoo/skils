# PrimeVue Navbar Component

Barra de navegação superior.

## Import

```javascript
import Navbar from 'primevue/navbar';
```

## Uso Básico

```vue
<Navbar>
  <template #start>Logo</template>
  <template #end>
    <Button label="Login" />
  </template>
</Navbar>
```

## Slots

| Slot | Descrição |
|------|-----------|
| `start` | Conteúdo à esquerda |
| `end` | Conteúdo à direita |

## Exemplos

### Básico

```vue
<Navbar>
  <template #start>
    <h2>Minha App</h2>
  </template>
  <template #end>
    <Button label="Login" />
  </template>
</Navbar>
```

### Com Menu

```vue
<Navbar>
  <template #start>
    <img src="/logo.png" alt="Logo" />
  </template>
  <template #end>
    <Menu :model="menuItems" />
    <Button label="Entrar" />
  </template>
</Navbar>
```

### Com Busca

```vue
<Navbar>
  <template #start>
    <h2>E-commerce</h2>
  </template>
  <template #end>
    <IconField>
      <InputIcon class="pi pi-search" />
      <InputText v-model="busca" placeholder="Buscar produtos..." />
    </IconField>
    <Button icon="pi pi-shopping-cart" />
  </template>
</Navbar>
```

### Responsivo

```vue
<Navbar>
  <template #start>
    <h2>App</h2>
  </template>
  <template #end>
    <div class="hidden md:flex gap-2">
      <Button label="Home" />
      <Button label="Sobre" />
    </div>
    <Button icon="pi pi-bars" class="md:hidden" />
  </template>
</Navbar>
```

## Casos de Uso

- Header de aplicação
- Navegação principal
- Barra superior fixa
- Menu de topo

## Referências

- [Documentação Oficial](https://primevue.org/navbar)
- [API Reference](https://primevue.org/api/navbar)
