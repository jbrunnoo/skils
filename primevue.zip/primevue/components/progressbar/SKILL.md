# PrimeVue ProgressBar Component

Componente de barra de progresso do PrimeVue.

## Import

```javascript
import ProgressBar from 'primevue/progressbar';
```

## Uso Básico

```vue
<ProgressBar :value="50" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | number | Valor (0-100) |
| `showValue` | boolean | Mostra valor |
| `mode` | string | "determinate", "indeterminate" |

## Exemplos

### Básico

```vue
<ProgressBar :value="75" />
```

### Indeterminado

```vue
<ProgressBar mode="indeterminate" />
```

### Com Valor

```vue
<ProgressBar :value="60" :showValue="true" />
```

## Referências

- [Documentação Oficial](https://primevue.org/progressbar)
- [API Reference](https://primevue.org/api/progressbar)
