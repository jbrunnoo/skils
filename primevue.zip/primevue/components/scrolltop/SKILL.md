# PrimeVue ScrollTop Component

Botão para voltar ao topo da página.

## Import

```javascript
import ScrollTop from 'primevue/scrolltop';
```

## Uso Básico

```vue
<ScrollTop />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `target` | string | Seletor do elemento alvo (default: "window") |
| `threshold` | number | Pixels para mostrar o botão (default: 400) |
| `icon` | string | Ícone customizado |
| `behavior` | string | Comportamento: "smooth" ou "auto" |

## Exemplos

### Básico

```vue
<template>
  <div>
    <div style="height: 2000px">
      Conteúdo longo...
    </div>
    <ScrollTop />
  </div>
</template>
```

### Com Threshold Customizado

```vue
<ScrollTop :threshold="200" />
```

### Com Ícone Customizado

```vue
<ScrollTop icon="pi pi-arrow-up" />
```

### Com Comportamento

```vue
<ScrollTop behavior="smooth" />
```

### Para Container Específico

```vue
<template>
  <div ref="container" style="height: 500px; overflow-y: auto">
    <div style="height: 2000px">Conteúdo</div>
    <ScrollTop :target="'#' + containerId" />
  </div>
</template>

<script setup>
const containerId = 'my-container'
</script>
```

## Casos de Uso

- Páginas longas
- Listas extensas
- Melhorar navegação
- UX em conteúdo longo

## Referências

- [Documentação Oficial](https://primevue.org/scrolltop)
- [API Reference](https://primevue.org/api/scrolltop)
