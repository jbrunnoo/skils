# PrimeVue VirtualScroller Component

Scroll virtual para grandes listas (performance).

## Import

```javascript
import VirtualScroller from 'primevue/virtualscroller';
```

## Uso Básico

```vue
<VirtualScroller :items="items" :itemSize="50" :delay="250">
  <template #item="{ item }">{{ item }}</template>
</VirtualScroller>
```

## Melhor Prática

Use `delay` para melhorar performance em scroll rápido.

## Referências

- [Documentação Oficial](https://primevue.org/virtualscroller)
- [API Reference](https://primevue.org/api/virtualscroller)
