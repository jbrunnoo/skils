# PrimeVue Menu Component

Componente de menu do PrimeVue.

## Import

```javascript
import Menu from 'primevue/menu';
```

## Uso Básico

```vue
<Menu :model="items" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do menu |
| `popup` | boolean | Menu popup (overlay) |
| `appendTo` | string | Onde anexar (default: "body") |

## Exemplos

### Menu Horizontal

```vue
<template>
  <Menu :model="itens" />
</template>

<script setup>
const itens = ref([
  {
    label: 'Arquivo',
    items: [
      { label: 'Novo', icon: 'pi pi-plus' },
      { label: 'Abrir', icon: 'pi pi-folder-open' }
    ]
  },
  {
    label: 'Editar',
    items: [
      { label: 'Copiar', icon: 'pi pi-copy' },
      { label: 'Colar', icon: 'pi pi-paste' }
    ]
  }
])
</script>
```

### Menu Popup

```vue
<template>
  <Button label="Menu" @click="menu.toggle($event)" />
  <Menu ref="menu" :model="itens" popup />
</template>

<script setup>
const menu = ref()
const itens = ref([
  { label: 'Opção 1', icon: 'pi pi-home' },
  { label: 'Opção 2', icon: 'pi pi-user' }
])
</script>
```

### Menu com Ações

```vue
const itens = ref([
  {
    label: 'Ações',
    items: [
      {
        label: 'Editar',
        icon: 'pi pi-pencil',
        command: () => editar()
      },
      {
        label: 'Deletar',
        icon: 'pi pi-trash',
        command: () => deletar()
      }
    ]
  }
])
```

## Referências

- [Documentação Oficial](https://primevue.org/menu)
- [API Reference](https://primevue.org/api/menu)
