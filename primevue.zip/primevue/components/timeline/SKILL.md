# PrimeVue Timeline Component

Componente de linha do tempo para exibir eventos em ordem cronológica.

## Import

```javascript
import Timeline from 'primevue/timeline';
```

## Uso Básico

```vue
<Timeline :value="events">
  <template #content="slotProps">
    <div>{{ slotProps.item }}</div>
  </template>
</Timeline>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Eventos da timeline |
| `align` | string | Alinhamento: "left", "right", "alternate", "top", "bottom" |
| `layout` | string | Layout: "vertical" ou "horizontal" |

## Exemplos

### Básico

```vue
<template>
  <Timeline :value="eventos">
    <template #content="slotProps">
      <Card>
        <template #title>{{ slotProps.item.titulo }}</template>
        <template #content>
          <p>{{ slotProps.item.descricao }}</p>
          <small>{{ slotProps.item.data }}</small>
        </template>
      </Card>
    </template>
  </Timeline>
</template>

<script setup>
const eventos = ref([
  {
    titulo: 'Evento 1',
    descricao: 'Descrição do evento',
    data: '2024-01-01'
  },
  {
    titulo: 'Evento 2',
    descricao: 'Descrição do evento',
    data: '2024-01-15'
  }
])
</script>
```

### Com Alinhamento Alternado

```vue
<Timeline :value="eventos" align="alternate">
  <template #content="slotProps">...</template>
</Timeline>
```

### Horizontal

```vue
<Timeline :value="eventos" layout="horizontal">
  <template #content="slotProps">...</template>
</Timeline>
```

### Com Ícones

```vue
<Timeline :value="eventos">
  <template #marker="slotProps">
    <i :class="slotProps.item.icon"></i>
  </template>
  <template #content="slotProps">
    <div>{{ slotProps.item.titulo }}</div>
  </template>
</Timeline>
```

## Casos de Uso

- Histórico de pedidos
- Timeline de atividades
- Linha do tempo de projeto
- Eventos cronológicos

## Referências

- [Documentação Oficial](https://primevue.org/timeline)
- [API Reference](https://primevue.org/api/timeline)
