# PrimeVue Tree Component

Componente de árvore hierárquica para exibir dados em estrutura de árvore.

## Import

```javascript
import Tree from 'primevue/tree';
```

## Uso Básico

```vue
<Tree :value="nodes" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Nós da árvore |
| `selectionMode` | string | "single", "multiple", "checkbox" |
| `selection` | any | Nó(s) selecionado(s) (v-model:selection) |
| `expandedKeys` | object | Chaves expandidas (v-model:expandedKeys) |
| `filter` | boolean | Habilita filtro |
| `filterPlaceholder` | string | Placeholder do filtro |

## Exemplos

### Básico

```vue
<template>
  <Tree :value="nodes" />
</template>

<script setup>
const nodes = ref([
  {
    key: '0',
    label: 'Documentos',
    children: [
      {
        key: '0-0',
        label: 'Trabalho',
        children: [
          { key: '0-0-0', label: 'Relatório.pdf' },
          { key: '0-0-1', label: 'Apresentação.pptx' }
        ]
      },
      {
        key: '0-1',
        label: 'Pessoal',
        children: [
          { key: '0-1-0', label: 'Fotos' },
          { key: '0-1-1', label: 'Vídeos' }
        ]
      }
    ]
  }
])
</script>
```

### Com Seleção

```vue
<Tree 
  :value="nodes" 
  v-model:selection="selecionado"
  selectionMode="single"
/>
```

### Seleção Múltipla

```vue
<Tree 
  :value="nodes" 
  v-model:selection="selecionados"
  selectionMode="multiple"
/>
```

### Com Checkbox

```vue
<Tree 
  :value="nodes" 
  v-model:selection="selecionados"
  selectionMode="checkbox"
/>
```

### Com Filtro

```vue
<Tree 
  :value="nodes" 
  filter
  filterPlaceholder="Buscar..."
/>
```

### Com Template Customizado

```vue
<Tree :value="nodes">
  <template #node="slotProps">
    <div class="flex items-center gap-2">
      <i :class="slotProps.node.icon"></i>
      <span>{{ slotProps.node.label }}</span>
    </div>
  </template>
</Tree>
```

## Estrutura de Nó

```typescript
interface TreeNode {
  key: string
  label: string
  data?: any
  icon?: string
  children?: TreeNode[]
  selectable?: boolean
  leaf?: boolean
}
```

## Casos de Uso

- Navegação de arquivos
- Menu hierárquico
- Estrutura organizacional
- Categorias aninhadas

## Referências

- [Documentação Oficial](https://primevue.org/tree)
- [API Reference](https://primevue.org/api/tree)
