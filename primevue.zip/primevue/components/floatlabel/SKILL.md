# PrimeVue FloatLabel Component

Label flutuante (legacy - use IftaLabel para versão moderna).

## Import

```javascript
import FloatLabel from 'primevue/floatlabel';
```

## Uso Básico

```vue
<FloatLabel>
  <InputText id="username" v-model="username" />
  <label for="username">Usuário</label>
</FloatLabel>
```

## Exemplos

### Básico

```vue
<template>
  <FloatLabel>
    <InputText id="email" v-model="email" />
    <label for="email">Email</label>
  </FloatLabel>
</template>
```

### Com Select

```vue
<FloatLabel>
  <Select id="pais" v-model="pais" :options="paises" />
  <label for="pais">País</label>
</FloatLabel>
```

### Com Textarea

```vue
<FloatLabel>
  <Textarea id="mensagem" v-model="mensagem" />
  <label for="mensagem">Mensagem</label>
</FloatLabel>
```

## Migração para IftaLabel

```vue
<!-- FloatLabel (legacy) -->
<FloatLabel>
  <InputText id="username" v-model="username" />
  <label for="username">Usuário</label>
</FloatLabel>

<!-- IftaLabel (recomendado v4) -->
<IftaLabel for="username">Usuário</IftaLabel>
<InputText id="username" v-model="username" />
```

## Referências

- [Documentação Oficial](https://primevue.org/floatlabel)
- [API Reference](https://primevue.org/api/floatlabel)
