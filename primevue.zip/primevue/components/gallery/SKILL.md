# PrimeVue Gallery Component

Componente de galeria de imagens com thumbnail e preview.

## Import

```javascript
import Gallery from 'primevue/gallery';
```

## Uso Básico

```vue
<Gallery :value="images" :numVisible="5" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Array de imagens |
| `numVisible` | number | Número de thumbnails visíveis |
| `responsiveOptions` | array | Opções responsivas |
| `showItemNavigators` | boolean | Mostra navegadores |
| `showThumbnails` | boolean | Mostra thumbnails |
| `showIndicators` | boolean | Mostra indicadores |

## Exemplos

### Básico

```vue
<template>
  <Gallery :value="imagens" :numVisible="5" />
</template>

<script setup>
const imagens = ref([
  {
    itemImageSrc: 'https://example.com/img1.jpg',
    thumbnailImageSrc: 'https://example.com/thumb1.jpg',
    alt: 'Imagem 1'
  },
  {
    itemImageSrc: 'https://example.com/img2.jpg',
    thumbnailImageSrc: 'https://example.com/thumb2.jpg',
    alt: 'Imagem 2'
  }
])
</script>
```

### Sem Thumbnails

```vue
<Gallery :value="imagens" :numVisible="1" :showThumbnails="false" />
```

### Com Template Customizado

```vue
<Gallery :value="imagens" :numVisible="5">
  <template #item="slotProps">
    <img :src="slotProps.item.itemImageSrc" :alt="slotProps.item.alt" />
  </template>
  <template #thumbnail="slotProps">
    <img :src="slotProps.item.thumbnailImageSrc" :alt="slotProps.item.alt" />
  </template>
</Gallery>
```

## Estrutura de Imagem

```typescript
interface GalleryItem {
  itemImageSrc: string
  thumbnailImageSrc: string
  alt?: string
  title?: string
}
```

## Referências

- [Documentação Oficial](https://primevue.org/gallery)
- [API Reference](https://primevue.org/api/gallery)
