# PrimeVue Mask Directive

Diretiva para aplicar máscara de input (ex: telefone, CPF).

## Import

```javascript
import Mask from 'primevue/mask';
```

## Configuração

```javascript
app.directive('mask', Mask);
```

## Uso Básico

```vue
<InputText v-model="phone" v-mask="'(99) 99999-9999'" />
```

## Padrões de Máscara

| Caractere | Descrição |
|-----------|-----------|
| `9` | Número (0-9) |
| `a` | Letra (a-z, A-Z) |
| `*` | Alfanumérico |

## Exemplos

### Telefone

```vue
<InputText 
  v-model="telefone" 
  v-mask="'(99) 99999-9999'"
  placeholder="(00) 00000-0000"
/>
```

### CPF

```vue
<InputText 
  v-model="cpf" 
  v-mask="'999.999.999-99'"
  placeholder="000.000.000-00"
/>
```

### CNPJ

```vue
<InputText 
  v-model="cnpj" 
  v-mask="'99.999.999/9999-99'"
  placeholder="00.000.000/0000-00"
/>
```

### CEP

```vue
<InputText 
  v-model="cep" 
  v-mask="'99999-999'"
  placeholder="00000-000"
/>
```

### Data

```vue
<InputText 
  v-model="data" 
  v-mask="'99/99/9999'"
  placeholder="dd/mm/aaaa"
/>
```

### Placa de Carro

```vue
<InputText 
  v-model="placa" 
  v-mask="'AAA-9999'"
  placeholder="ABC-1234"
/>
```

### Com Placeholder

```vue
<InputText 
  v-model="valor" 
  v-mask="'R$ 999.999,99'"
  placeholder="R$ 000.000,00"
/>
```

## Casos de Uso

- Formatação de telefones
- Máscaras de documentos
- Formatação de valores
- Inputs com padrão específico

## Referências

- [Documentação Oficial](https://primevue.org/mask)
- [API Reference](https://primevue.org/api/mask)
