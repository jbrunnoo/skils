# PrimeVue RadioButton Component

Componente de radio button do PrimeVue.

## Import

```javascript
import RadioButton from 'primevue/radiobutton';
```

## Uso Básico

```vue
<RadioButton v-model="selecionado" value="opcao1" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | any | Valor selecionado (v-model) |
| `value` | any | Valor desta opção |
| `disabled` | boolean | Desabilita |
| `invalid` | boolean | Estado inválido |

## Exemplos

### Básico

```vue
<template>
  <RadioButton v-model="escolha" value="sim" inputId="sim" />
  <label for="sim">Sim</label>
  
  <RadioButton v-model="escolha" value="nao" inputId="nao" />
  <label for="nao">Não</label>
</template>

<script setup>
const escolha = ref('sim')
</script>
```

### Grupo de Opções

```vue
<template>
  <div v-for="opcao in opcoes" :key="opcao.value">
    <RadioButton 
      v-model="selecionado" 
      :value="opcao.value" 
      :inputId="opcao.value"
    />
    <label :for="opcao.value">{{ opcao.label }}</label>
  </div>
</template>

<script setup>
const selecionado = ref(null)
const opcoes = [
  { label: 'Opção 1', value: 'op1' },
  { label: 'Opção 2', value: 'op2' }
]
</script>
```

## Referências

- [Documentação Oficial](https://primevue.org/radiobutton)
- [API Reference](https://primevue.org/api/radiobutton)
