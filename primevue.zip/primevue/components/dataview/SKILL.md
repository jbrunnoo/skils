# PrimeVue DataView Component

Componente de visualização de dados com múltiplos layouts (grid, list).

## Import

```javascript
import DataView from 'primevue/dataview';
import DataViewLayoutOptions from 'primevue/dataviewlayoutoptions';
```

## Uso Básico

```vue
<DataView :value="products" layout="grid">
  <template #list="slotProps">
    <div v-for="item in slotProps.items">{{ item.name }}</div>
  </template>
  <template #grid="slotProps">
    <div v-for="item in slotProps.items">{{ item.name }}</div>
  </template>
</DataView>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Dados |
| `layout` | string | Layout: "list" ou "grid" |
| `paginator` | boolean | Habilita paginação |
| `rows` | number | Itens por página |
| `sortField` | string | Campo para ordenação |
| `sortOrder` | number | Ordem: 1 (asc), -1 (desc) |
| `dataKey` | string | Chave única |

## Exemplos

### Grid

```vue
<template>
  <DataView :value="produtos" layout="grid">
    <template #grid="slotProps">
      <div class="grid">
        <div v-for="produto in slotProps.items" :key="produto.id" class="col-12 md:col-4">
          <Card>
            <template #title>{{ produto.nome }}</template>
            <template #content>
              <p>{{ produto.descricao }}</p>
              <p class="font-bold">R$ {{ produto.preco }}</p>
            </template>
          </Card>
        </div>
      </div>
    </template>
  </DataView>
</template>
```

### List

```vue
<DataView :value="produtos" layout="list">
  <template #list="slotProps">
    <div v-for="produto in slotProps.items" :key="produto.id" class="mb-3">
      <div class="flex justify-between">
        <span>{{ produto.nome }}</span>
        <span>R$ {{ produto.preco }}</span>
      </div>
    </div>
  </template>
</DataView>
```

### Com Layout Options

```vue
<template>
  <DataViewLayoutOptions v-model="layout" />
  <DataView :value="produtos" :layout="layout">
    <template #list="slotProps">...</template>
    <template #grid="slotProps">...</template>
  </DataView>
</template>

<script setup>
const layout = ref('grid')
</script>
```

### Com Paginação

```vue
<DataView 
  :value="produtos" 
  layout="grid"
  paginator
  :rows="12"
>
  <template #grid="slotProps">...</template>
</DataView>
```

### Com Ordenação

```vue
<DataView 
  :value="produtos" 
  layout="grid"
  sortField="preco"
  :sortOrder="1"
>
  <template #grid="slotProps">...</template>
</DataView>
```

## Casos de Uso

- Galeria de produtos
- Lista/grid de itens
- Visualização alternada de dados
- E-commerce

## Referências

- [Documentação Oficial](https://primevue.org/dataview)
- [API Reference](https://primevue.org/api/dataview)
