# PrimeVue Breadcrumb Component

Componente de breadcrumb para navegação hierárquica.

## Import

```javascript
import Breadcrumb from 'primevue/breadcrumb';
```

## Uso Básico

```vue
<Breadcrumb :model="items" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do breadcrumb |
| `home` | object | Item home customizado |
| `exact` | boolean | Match exato para router-link |

## Exemplos

### Básico

```vue
<template>
  <Breadcrumb :model="items" />
</template>

<script setup>
const items = ref([
  { label: 'Home' },
  { label: 'Produtos' },
  { label: 'Eletrônicos' },
  { label: 'Smartphones' }
])
</script>
```

### Com Links

```vue
<template>
  <Breadcrumb :model="items" />
</template>

<script setup>
const items = ref([
  { label: 'Home', to: '/' },
  { label: 'Produtos', to: '/produtos' },
  { label: 'Detalhes' }
])
</script>
```

### Com Ícones

```vue
const items = ref([
  { label: 'Home', icon: 'pi pi-home', to: '/' },
  { label: 'Produtos', icon: 'pi pi-box', to: '/produtos' },
  { label: 'Detalhes' }
])
```

### Com Home Customizado

```vue
<Breadcrumb :model="items" :home="homeItem" />

<script setup>
const homeItem = ref({
  icon: 'pi pi-home',
  to: '/'
})
</script>
```

### Com Router

```vue
<Breadcrumb :model="items" :exact="false" />
```

## Estrutura de Item

```typescript
interface BreadcrumbItem {
  label: string
  to?: string
  icon?: string
  command?: () => void
  items?: BreadcrumbItem[]
}
```

## Casos de Uso

- Navegação hierárquica em e-commerce
- Breadcrumbs em dashboards
- Navegação em documentação
- Indicadores de localização

## Referências

- [Documentação Oficial](https://primevue.org/breadcrumb)
- [API Reference](https://primevue.org/api/breadcrumb)
