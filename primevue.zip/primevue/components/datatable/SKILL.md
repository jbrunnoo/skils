# PrimeVue DataTable Component

Componente de tabela de dados avançado do PrimeVue com ordenação, filtragem, paginação e muito mais.

## Import

```javascript
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
```

## Uso Básico

```vue
<DataTable :value="products">
  <Column field="name" header="Nome" />
  <Column field="price" header="Preço" />
</DataTable>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Dados da tabela |
| `paginator` | boolean | Habilita paginação |
| `rows` | number | Itens por página |
| `sortField` | string | Campo para ordenação |
| `sortOrder` | number | Ordem: 1 (asc), -1 (desc) |
| `filters` | object | Filtros |
| `selection` | any | Linha(s) selecionada(s) |
| `dataKey` | string | Chave única (recomendado) |
| `expandedRows` | object | Linhas expandidas (use objeto, não array) |
| `stateStorage` | string | Persistência: "session", "local" |
| `stateKey` | string | Chave para persistência |

## Exemplos

### Básico

```vue
<template>
  <DataTable :value="produtos">
    <Column field="nome" header="Nome" />
    <Column field="preco" header="Preço" />
    <Column field="estoque" header="Estoque" />
  </DataTable>
</template>

<script setup>
import { ref } from 'vue'
const produtos = ref([
  { nome: 'Produto 1', preco: 100, estoque: 10 },
  { nome: 'Produto 2', preco: 200, estoque: 5 }
])
</script>
```

### Com Paginação

```vue
<DataTable :value="produtos" paginator :rows="10">
  <Column field="nome" header="Nome" />
  <Column field="preco" header="Preço" />
</DataTable>
```

### Com Ordenação

```vue
<DataTable :value="produtos" sortField="nome" :sortOrder="1">
  <Column field="nome" header="Nome" sortable />
  <Column field="preco" header="Preço" sortable />
</DataTable>
```

### Com Filtro

```vue
<DataTable :value="produtos" :filters="filters" filterDisplay="row">
  <Column field="nome" header="Nome">
    <template #filter="{ filterModel, filterCallback }">
      <InputText v-model="filterModel.value" @input="filterCallback()" />
    </template>
  </Column>
</DataTable>
```

### Seleção

```vue
<DataTable 
  :value="produtos" 
  v-model:selection="selected" 
  selectionMode="single"
  dataKey="id"
>
  <Column selectionMode="single" />
  <Column field="nome" header="Nome" />
</DataTable>
```

### Linhas Expandidas (Performance)

```vue
<template>
  <DataTable 
    :value="produtos" 
    v-model:expandedRows="expandedRows"
    dataKey="id"
  >
    <Column :expander="true" />
    <Column field="nome" header="Nome" />
    <template #expansion="{ data }">
      <div>Detalhes: {{ data.descricao }}</div>
    </template>
  </DataTable>
</template>

<script setup>
// ✅ PREFERIDO: Use objeto para O(1) lookup
const expandedRows = ref({ '1': true, '2': true })

// ❌ EVITE: Array é O(n) lookup
// const expandedRows = ref([produtos[0], produtos[1]])
</script>
```

### Persistência de Estado

```vue
<DataTable 
  :value="produtos"
  stateStorage="local"
  stateKey="produtos-table"
  :filters="filters"
  :sortField="sortField"
>
  <!-- Estado salvo automaticamente no localStorage -->
</DataTable>
```

### Menu de Contexto

```vue
<template>
  <ContextMenu ref="cm" :model="menuItems" />
  <DataTable 
    :value="produtos" 
    contextMenu
    @row-contextmenu="onRowContextMenu"
  >
    <Column field="nome" header="Nome" />
  </DataTable>
</template>

<script setup>
const cm = ref()
const menuItems = ref([
  { label: 'Editar', icon: 'pi pi-pencil' },
  { label: 'Deletar', icon: 'pi pi-trash' }
])

const onRowContextMenu = (event) => {
  cm.value.show(event.originalEvent)
}
</script>
```

## Melhores Práticas

1. **Sempre use `dataKey`** para performance
2. **Use objeto para `expandedRows`** ao invés de array
3. **Habilite `stateStorage`** para melhor UX
4. **Use `virtualScroller`** para listas muito grandes (>1000 itens)

## Referências

- [Documentação Oficial](https://primevue.org/datatable)
- [API Reference](https://primevue.org/api/datatable)
