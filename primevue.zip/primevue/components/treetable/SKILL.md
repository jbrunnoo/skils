# PrimeVue TreeTable Component

Tabela em estrutura de árvore hierárquica.

## Import

```javascript
import TreeTable from 'primevue/treetable';
import Column from 'primevue/column';
```

## Uso Básico

```vue
<TreeTable :value="nodes">
  <Column field="name" header="Nome" />
  <Column field="size" header="Tamanho" />
</TreeTable>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `value` | array | Nós da árvore |
| `selectionMode` | string | "single", "multiple", "checkbox" |
| `selection` | any | Nó(s) selecionado(s) |
| `expandedKeys` | object | Chaves expandidas |
| `paginator` | boolean | Habilita paginação |
| `sortField` | string | Campo para ordenação |

## Exemplos

### Básico

```vue
<template>
  <TreeTable :value="nodes">
    <Column field="name" header="Nome" expander />
    <Column field="size" header="Tamanho" />
    <Column field="type" header="Tipo" />
  </TreeTable>
</template>

<script setup>
const nodes = ref([
  {
    key: '0',
    data: { name: 'Aplicações', size: '100kb', type: 'Pasta' },
    children: [
      {
        key: '0-0',
        data: { name: 'React', size: '25kb', type: 'Pasta' },
        children: [
          { key: '0-0-0', data: { name: 'react.app', size: '10kb', type: 'Arquivo' } }
        ]
      }
    ]
  }
])
</script>
```

### Com Seleção

```vue
<TreeTable 
  :value="nodes" 
  v-model:selection="selecionado"
  selectionMode="single"
>
  <Column field="name" header="Nome" expander />
  <Column field="size" header="Tamanho" />
</TreeTable>
```

### Com Paginação

```vue
<TreeTable 
  :value="nodes" 
  paginator
  :rows="10"
>
  <Column field="name" header="Nome" expander />
</TreeTable>
```

## Estrutura de Dados

```typescript
interface TreeNode {
  key: string
  data: {
    [key: string]: any
  }
  children?: TreeNode[]
}
```

## Casos de Uso

- Navegador de arquivos
- Estrutura organizacional
- Hierarquia de dados
- Tabelas expandíveis

## Referências

- [Documentação Oficial](https://primevue.org/treetable)
- [API Reference](https://primevue.org/api/treetable)
