# PrimeVue Message Component

Componente de mensagem inline do PrimeVue.

## Import

```javascript
import Message from 'primevue/message';
```

## Uso Básico

```vue
<Message severity="success" text="Operação realizada com sucesso" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `severity` | string | "success", "info", "warn", "error" |
| `text` | string | Texto da mensagem |
| `closable` | boolean | Permite fechar |

## Exemplos

### Básico

```vue
<Message severity="success" text="Sucesso!" />
```

### Com Fechar

```vue
<Message severity="error" text="Erro!" :closable="true" />
```

## Referências

- [Documentação Oficial](https://primevue.org/message)
- [API Reference](https://primevue.org/api/message)
