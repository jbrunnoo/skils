# PrimeVue MegaMenu Component

Menu mega com múltiplas colunas e layouts complexos.

## Import

```javascript
import MegaMenu from 'primevue/megamenu';
```

## Uso Básico

```vue
<MegaMenu :model="items" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do menu |
| `orientation` | string | "horizontal" ou "vertical" |
| `breakpoint` | string | Breakpoint para mobile |

## Exemplos

### Básico

```vue
<template>
  <MegaMenu :model="items" />
</template>

<script setup>
const items = ref([
  {
    label: 'Produtos',
    items: [
      [
        {
          label: 'Eletrônicos',
          items: [
            { label: 'Smartphones' },
            { label: 'Tablets' },
            { label: 'Notebooks' }
          ]
        },
        {
          label: 'Casa',
          items: [
            { label: 'Móveis' },
            { label: 'Decoração' }
          ]
        }
      ]
    ]
  },
  {
    label: 'Serviços',
    items: [
      [
        {
          label: 'Consultoria' },
        {
          label: 'Suporte' }
      ]
    ]
  }
])
</script>
```

### Com Ícones

```vue
const items = ref([
  {
    label: 'Produtos',
    icon: 'pi pi-box',
    items: [
      [
        {
          label: 'Categoria 1',
          items: [
            { label: 'Item 1', icon: 'pi pi-star' },
            { label: 'Item 2', icon: 'pi pi-star' }
          ]
        }
      ]
    ]
  }
])
```

### Vertical

```vue
<MegaMenu :model="items" orientation="vertical" />
```

## Estrutura de Dados

```typescript
interface MegaMenuItem {
  label: string
  icon?: string
  items?: MegaMenuItem[][]
  command?: () => void
}
```

## Casos de Uso

- Menus de e-commerce
- Navegação complexa
- Categorias múltiplas
- Mega menus horizontais

## Referências

- [Documentação Oficial](https://primevue.org/megamenu)
- [API Reference](https://primevue.org/api/megamenu)
