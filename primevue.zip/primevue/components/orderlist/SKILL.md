# PrimeVue OrderList Component

Lista ordenável com drag and drop para reordenar itens.

## Import

```javascript
import OrderList from 'primevue/orderlist';
```

## Uso Básico

```vue
<OrderList v-model="items" listStyle="height:250px">
  <template #item="slotProps">
    <div>{{ slotProps.item }}</div>
  </template>
</OrderList>
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | array | Itens (v-model) |
| `listStyle` | string | Estilo da lista |
| `dataKey` | string | Chave única |
| `disabled` | boolean | Desabilita drag |

## Exemplos

### Básico

```vue
<template>
  <OrderList v-model="itens" listStyle="height: 300px">
    <template #item="slotProps">
      <div class="p-2 border">
        {{ slotProps.item.nome }}
      </div>
    </template>
  </OrderList>
</template>

<script setup>
const itens = ref([
  { id: 1, nome: 'Item 1' },
  { id: 2, nome: 'Item 2' },
  { id: 3, nome: 'Item 3' }
])
</script>
```

### Com Objetos

```vue
<OrderList 
  v-model="produtos" 
  listStyle="height: 400px"
  dataKey="id"
>
  <template #item="slotProps">
    <div class="flex justify-between p-2">
      <span>{{ slotProps.item.nome }}</span>
      <span>R$ {{ slotProps.item.preco }}</span>
    </div>
  </template>
</OrderList>
```

### Com Ícones de Ordenação

```vue
<OrderList v-model="itens" listStyle="height: 300px">
  <template #item="slotProps">
    <div class="flex items-center gap-2 p-2">
      <i class="pi pi-bars text-gray-400"></i>
      <span>{{ slotProps.item }}</span>
    </div>
  </template>
</OrderList>
```

## Casos de Uso

- Reordenar lista de itens
- Organizar prioridades
- Ordenar categorias
- Gerenciar sequência

## Referências

- [Documentação Oficial](https://primevue.org/orderlist)
- [API Reference](https://primevue.org/api/orderlist)
