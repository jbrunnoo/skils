# PrimeVue Dock Component

Componente dock estilo macOS para aplicativos/ações rápidas.

## Import

```javascript
import Dock from 'primevue/dock';
```

## Uso Básico

```vue
<Dock :model="items" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `model` | array | Itens do dock |
| `position` | string | Posição: "bottom", "top", "left", "right" |
| `tooltipOptions` | object | Opções do tooltip |

## Exemplos

### Básico

```vue
<template>
  <Dock :model="items" position="bottom" />
</template>

<script setup>
const items = ref([
  {
    label: 'Home',
    icon: 'pi pi-home',
    command: () => navegar('/')
  },
  {
    label: 'Produtos',
    icon: 'pi pi-box',
    command: () => navegar('/produtos')
  },
  {
    label: 'Configurações',
    icon: 'pi pi-cog',
    command: () => navegar('/config')
  }
])
</script>
```

### Com Imagens

```vue
const items = ref([
  {
    label: 'App 1',
    icon: () => h('img', { src: '/app1.png' })
  },
  {
    label: 'App 2',
    icon: () => h('img', { src: '/app2.png' })
  }
])
```

### Posições

```vue
<Dock :model="items" position="bottom" />
<Dock :model="items" position="top" />
<Dock :model="items" position="left" />
<Dock :model="items" position="right" />
```

## Casos de Uso

- Dock de aplicativos
- Ações rápidas
- Navegação principal
- Atalhos visuais

## Referências

- [Documentação Oficial](https://primevue.org/dock)
- [API Reference](https://primevue.org/api/dock)
