# PrimeVue MultiSelect Component

Componente de seleção múltipla do PrimeVue.

## Import

```javascript
import MultiSelect from 'primevue/multiselect';
```

## Uso Básico

```vue
<MultiSelect v-model="selected" :options="options" optionLabel="name" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | array | Valores selecionados (v-model) |
| `options` | array | Opções disponíveis |
| `optionLabel` | string | Propriedade para label |
| `optionValue` | string | Propriedade para value |
| `display` | string | "comma", "chip" |
| `maxSelectedLabels` | number | Máximo de labels visíveis |
| `selectionLimit` | number | Limite de seleção |
| `filter` | boolean | Habilita filtro |

## Exemplos

### Básico

```vue
<template>
  <MultiSelect 
    v-model="selecionados" 
    :options="opcoes" 
    optionLabel="name"
    placeholder="Selecione"
  />
</template>

<script setup>
const selecionados = ref([])
const opcoes = [
  { name: 'Opção 1', value: 'op1' },
  { name: 'Opção 2', value: 'op2' }
]
</script>
```

### Com Chips

```vue
<MultiSelect 
  v-model="selecionados" 
  :options="opcoes" 
  optionLabel="name"
  display="chip"
/>
```

### Com Filtro

```vue
<MultiSelect 
  v-model="selecionados" 
  :options="opcoes" 
  optionLabel="name"
  filter
/>
```

## Referências

- [Documentação Oficial](https://primevue.org/multiselect)
- [API Reference](https://primevue.org/api/multiselect)
