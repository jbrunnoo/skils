# PrimeVue Textarea Component

Componente de textarea do PrimeVue.

## Import

```javascript
import Textarea from 'primevue/textarea';
```

## Uso Básico

```vue
<Textarea v-model="texto" />
```

## Props Principais

| Prop | Tipo | Descrição |
|------|------|-----------|
| `modelValue` | string | Valor (v-model) |
| `rows` | number | Número de linhas |
| `cols` | number | Número de colunas |
| `autoResize` | boolean | Auto-redimensiona |
| `disabled` | boolean | Desabilita |
| `readonly` | boolean | Somente leitura |

## Exemplos

### Básico

```vue
<Textarea v-model="mensagem" rows="5" />
```

### Auto-resize

```vue
<Textarea v-model="mensagem" :autoResize="true" rows="3" />
```

## Referências

- [Documentação Oficial](https://primevue.org/textarea)
- [API Reference](https://primevue.org/api/textarea)
