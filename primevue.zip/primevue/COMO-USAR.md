# 🚀 Como Usar o System Prompt do PrimeVue

## 📋 Passo a Passo

### 1. Copie o arquivo `.cursorrules` para seu projeto

Copie o arquivo `.cursorrules` da pasta de skills para a **raiz do seu projeto Vue/PrimeVue**:

```bash
# Exemplo: copiar para um projeto
cp /Users/jeffersonbruno/skills/primevue/.cursorrules /caminho/do/seu/projeto/.cursorrules
```

### 2. O Cursor detecta automaticamente

O Cursor automaticamente lê o arquivo `.cursorrules` na raiz do projeto e passa a usar as skills do PrimeVue.

### 3. Use normalmente

Agora você pode pedir ao Cursor:

- ✅ "Crie um botão usando PrimeVue"
- ✅ "Crie uma tabela de dados"
- ✅ "Configure o PrimeVue no projeto"
- ✅ "Crie um modal de confirmação"

O Cursor automaticamente consultará as skills corretas!

## 📁 Estrutura Recomendada

```
seu-projeto/
├── .cursorrules          ← Copie este arquivo aqui
├── package.json
├── src/
│   ├── main.ts
│   └── App.vue
└── ...
```

## 🎯 O que o System Prompt faz?

1. **Detecta componentes PrimeVue** automaticamente
2. **Consulta a skill correta** para cada componente
3. **Gera código atualizado** com v4
4. **Evita breaking changes** não documentados
5. **Usa padrões nativos** sem customizações pesadas

## ✨ Exemplo Prático

### Antes (sem system prompt):
```
Você: "Crie um botão"
Cursor: [gera código genérico, pode estar desatualizado]
```

### Depois (com system prompt):
```
Você: "Crie um botão"
Cursor: [consulta button/SKILL.md automaticamente]
Cursor: [gera código correto com PrimeVue v4]
```

## 🔧 Personalização

Se quiser ajustar o caminho das skills, edite o arquivo `.cursorrules` e altere:

```markdown
**Localização das Skills:** `/Users/jeffersonbruno/skills/primevue/`
```

Para o caminho onde suas skills estão localizadas.

## 📚 Mais Informações

- Veja `README.md` para lista completa de skills
- Cada skill tem exemplos práticos e referências
- Skills são atualizadas e focadas no essencial

---

**Pronto!** Agora o Cursor usará automaticamente as skills do PrimeVue em todos os seus projetos! 🎉
