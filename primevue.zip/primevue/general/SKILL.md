# PrimeVue - Guia Completo de Setup e Uso

> PrimeVue é uma biblioteca UI open-source para Vue.js com 80+ componentes, designer de temas, alternativas de temas (Material, Bootstrap, Tailwind), templates premium e suporte profissional. Integra com PrimeBlock, que oferece 370+ blocos de UI prontos para construir aplicações espetaculares rapidamente.

**Versão:** 4.5.4 (Dez 2025)  
**Dependências:** @primeuix/styled@^0.7.4, @primeuix/utils@^0.6.2, @primeuix/styles@^2.0.2, @primevue/core@4.5.4, @primevue/icons@4.5.4  
**Tags:** v2-stable: 2.10.4 (Dez 2023), v3-stable: 3.53.1 (Dez 2024), latest: 4.5.4 (Dez 2025)

**Referências:** [Documentação Oficial](https://primevue.org) | [API Reference](https://primevue.org/api) | [Guias](https://primevue.org/guides)

---

## Instalação

Instale PrimeVue e os temas:

```bash
npm install primevue @primeuix/themes
```

## Configuração do Plugin

Configure o plugin PrimeVue com tema em `main.ts`:

```typescript
import { createApp } from 'vue'
import PrimeVue from 'primevue/config'
import Aura from '@primeuix/themes/aura'
import App from './App.vue'

const app = createApp(App)
app.use(PrimeVue, {
  theme: {
    preset: Aura  // Disponível: Aura, Lara, Nora, etc.
  }
})
app.mount('#app')
```

## Auto-Import Setup

Instale as dependências de auto-import:

```bash
npm install -D unplugin-vue-components @primevue/auto-import-resolver
```

Configure em `vite.config.ts`:

```typescript
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import Components from 'unplugin-vue-components/vite'
import { PrimeVueResolver } from '@primevue/auto-import-resolver'

export default defineConfig({
  plugins: [
    vue(),
    Components({
      resolvers: [
        PrimeVueResolver()
      ]
    })
  ],
})
```

## Uso de Componentes

Com auto-import configurado, use componentes diretamente sem imports manuais:

```vue
<template>
  <Button label="Clique em Mim" />
  <InputText v-model="value" placeholder="Digite texto" />
  <DataTable :value="items" />
</template>

<script setup lang="ts">
import { ref } from 'vue'
// Nenhum import de componente PrimeVue necessário - gerenciado por auto-import

const value = ref('')
const items = ref([])
</script>
```

## Componentes Comuns

* **Button**: `<Button label="Texto" />`
* **InputText**: `<InputText v-model="value" />`
* **Select** (anteriormente Dropdown): `<Select v-model="selected" :options="items" />`
* **DataTable**: `<DataTable :value="data" />`
* **Dialog**: `<Dialog v-model:visible="show" />`
* **Card**: `<Card><template #title>Título</template></Card>`

## Temas

Temas preset disponíveis:

* **Aura** - Design moderno e limpo (recomendado)
* **Lara** - Inspirado em Material
* **Nora** - Minimalista

Importe e aplique na configuração do plugin conforme mostrado acima.

---

## Mudanças de API (Breaking Changes)

Esta seção documenta mudanças específicas de versão — priorize releases major/minor recentes.

### Mudanças de Nomenclatura (v3 → v4)

* **BREAKING**: `Calendar` renomeado para `DatePicker` — componente v3 renomeado para `DatePicker` na v4
* **BREAKING**: `Dropdown` renomeado para `Select` — componente v3 renomeado para `Select` na v4
* **BREAKING**: `Sidebar` renomeado para `Drawer` — componente v3 renomeado para `Drawer` na v4
* **BREAKING**: `OverlayPanel` renomeado para `Popover` — componente v3 renomeado para `Popover` na v4
* **BREAKING**: `InputSwitch` renomeado para `ToggleSwitch` — componente v3 renomeado para `ToggleSwitch` na v4

### Mudanças de Estrutura (v3 → v4)

* **BREAKING**: `TabView` substituído por `Tabs` — nova estrutura usando `TabList`, `Tab`, `TabPanels`, e `TabPanel`
* **BREAKING**: `Steps` substituído por `Stepper` — nova estrutura usando `StepList`, `Step`, `StepPanels`, e `StepPanel`
* **BREAKING**: `Accordion` reimplementado — agora usa componentes `AccordionPanel`, `AccordionHeader`, e `AccordionContent`

### Mudanças de API (v3 → v4)

* **BREAKING**: `v-model:value` — v4 usa `v-model:value` para estado ativo em `Tabs`, `Accordion`, e `Stepper` ao invés de `v-model`
* **DEPRECATED**: `inputStyle` — propriedade substituída por `inputVariant` (valores: 'filled' | 'outlined')

### Novos Recursos (v4)

* **NOVO**: `@primevue/forms` — novo pacote dedicado para gerenciamento avançado de formulários e validação
* **NOVO**: Componente `Fluid` — componente de layout que faz descendentes ocuparem largura total
* **NOVO**: `IconField` & `InputIcon` — novos componentes para envolver inputs e ícones para fins decorativos
* **NOVO**: `useId` & `useAttrSelector` — novos composables core para geração de ID único e seletores de atributos

### Outras Mudanças

* `DataTable` `showClearButton` padrão é `false` (v4.3.0)
* `IftaLabel` novo componente para labels in-field
* `Checkbox` adicionado estado `indeterminate`
* `OverlayBadge` novo componente substitui diretiva `Badge`
* Componente `InlineMessage` deprecated
* `iconPosition` removido de `IconField`
* Propriedade `warning` renomeada para `warn`
* `Drawer` adicionado emit `before-hide` (v4.3.0)

---

## Melhores Práticas

### Layout e Estilização

* Use o componente `Fluid` como wrapper para aplicação em massa de estilos full-width em inputs ao invés de adicionar a prop `fluid` em cada campo individual para templates mais limpos e manuteníveis:

```vue
<Fluid>
    <div class="grid grid-cols-2 gap-4">
        <InputText placeholder="Largura Total" />
        <DatePicker placeholder="Largura Total" />
        <Select placeholder="Largura Total" />
    </div>
</Fluid>
```

### Stepper e Tabs

* Em layouts verticais do Stepper, sempre envolva `Step` e `StepPanel` dentro de um componente `StepItem` para garantir estrutura correta e conexão entre headers e conteúdo
* Use `asChild` e `v-slot` em componentes como `Step` ou `Tab` para implementar modo headless para controle total da UI mantendo a lógica de acessibilidade built-in do PrimeVue:

```vue
<Step v-slot="{ activateCallback, value, a11yAttrs }" asChild :value="1">
    <button @click="activateCallback" v-bind="a11yAttrs.header">
        Passo {{ value }}
    </button>
</Step>
```

### Performance

* Para expansão performática de linhas em `DataTable` com grandes datasets, use um objeto para `expandedRows` combinado com `dataKey` ao invés de um array de objetos de linha:

```typescript
// Preferido (O(1) lookup)
const expandedRows = ref({ '1004': true, '1005': true });

// No template
<DataTable v-model:expandedRows="expandedRows" dataKey="id">
```

* Habilite persistência automática de preferências do usuário (ordenação, filtragem, paginação) em `DataTable` usando `stateStorage` e `stateKey` para melhorar UX entre visitas de página
* Adicione um `delay` ao `VirtualScroller` para throttling de renderização durante scroll rápido, melhorando significativamente a responsividade da UI para listas extremamente grandes:

```vue
<VirtualScroller :items="items" :itemSize="50" :delay="250">
    <template v-slot:item="{ item }">{{ item }}</template>
</VirtualScroller>
```

### Navegação e Acessibilidade

* Implemente menus de navegação semânticos usando `Tabs` sem `TabPanels` e combinando com `router-link` para barras superiores ou laterais acessíveis e state-aware
* Sempre envolva inputs e ícones com `IconField` e `InputIcon` para garantir posicionamento e estilização corretos, suportando tanto posicionamento leading quanto trailing de ícones:

```vue
<IconField>
    <InputIcon class="pi pi-search" />
    <InputText placeholder="Buscar" />
</IconField>
```

### Formulários e Validação

* Use `IftaLabel` para labels in-field modernos, top-aligned que se integram visualmente com o input e lidam com estados de validação automaticamente
* Aproveite a integração built-in de menu de contexto do `DataTable` para fornecer ações específicas de linha sem gerenciamento manual de event listeners ou lógica de posicionamento customizada:

```vue
<ContextMenu ref="cm" :model="menuModel" />
<DataTable :value="products" contextMenu @row-contextmenu="onRowContextMenu">
```

---

## Referências Adicionais

* **Documentação Oficial**: https://primevue.org
* **Documentação Otimizada para LLM**: https://primevue.org/llms/pages/introduction.md
* **Setup com Vite**: https://primevue.org/llms/pages/vite.md
* **Auto-import**: https://primevue.org/llms/pages/autoimport.md
* **PrimeBlocks**: https://primeblocks.org/ (370+ blocos de UI prontos)

---

## Resumo de Uso Rápido

### Setup Básico
1. Instale: `npm install primevue @primeuix/themes`
2. Configure o plugin em `main.ts` com tema
3. Configure auto-import (opcional mas recomendado)

### Componentes Mais Usados
- `Button`, `InputText`, `Select`, `DataTable`, `Dialog`, `Card`
- `DatePicker` (anteriormente Calendar)
- `Drawer` (anteriormente Sidebar)
- `Popover` (anteriormente OverlayPanel)
- `ToggleSwitch` (anteriormente InputSwitch)

### Temas Recomendados
- **Aura** - Para projetos modernos
- **Lara** - Para projetos Material Design
- **Nora** - Para projetos minimalistas
